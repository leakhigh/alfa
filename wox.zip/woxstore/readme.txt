=== WoxStore ===

Contributors: CozyThemes
Tags: blog, one-column, custom-background, custom-colors, custom-logo, custom-menu, editor-style, featured-images, e-commerce, full-site-editing, block-patterns, full-width-template, rtl-language-support, threaded-comments, translation-ready, block-styles, wide-blocks
Requires at least: 5.9
Tested up to: 6.7
Requires PHP: 7.4
Stable tag: 1.0.1
License: GNU General Public License v2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

== Description ==

 WoxStore is a minimal, clean, and versatile WooCommerce theme designed to help you launch and customize your online store effortlessly. Built with Full Site Editing (FSE), it gives you complete control over every element of your site, including the header, footer, product catalog, and blog layout. Ideal for any eCommerce niche — from fashion, beauty, and electronics to home decor, furniture, hardware, groceries, sports gear, jewelry, pet supplies, books, automotive parts, and kids products — WoxStore adapts to your brand’s unique style. With 9 professionally designed starter templates and a one-click demo import feature, setting up your store is quick and easy. Pre-built sections and templates make customization simple and intuitive, helping you create a high-converting store with minimal effort. Discover all features and live demos at https://cozythemes.com/woxstore-woocommerce-theme/

== Installation ==

1. In your admin panel, go to Appearance > Themes and click the Add New button.
2. Click Upload Theme and Choose File, then select the theme's .zip file. Click Install Now.
3. Click Activate to use your new theme right away.

== Frequently Asked Questions ==

= Does this theme support any plugins? =

"WoxStore" includes support for WooCommerce and for Infinite Scroll in Jetpack.

== Changelog ==
= 1.0.1 - March 20, 2025 =
* 404 page text color minor issue fixed
* Minor Layout improvement for FAQ section

= 1.0.0 - March 17, 2025 =
* Initial release

==Copyright==
"WoxStore" WordPress Theme, Copyright 2025 CozyThemes
"WoxStore" is distributed under the terms of the GNU GPL


== Credits ==
== Resources ==
Theme logo, Icons of service section and screenshot dummy dashboard, app section mobile mockup with our theme demo are created by our own.
License: GPL v2 or later

Image 1 fors slider in screenshot,  https://pxhere.com/
License: CC0 1.0 Universal (CC0 1.0)
License URL: https://creativecommons.org/publicdomain/zero/1.0/
Source: https://pxhere.com/en/photo/1540997

Image 2 fors slider in screenshot,  https://pxhere.com/
License: CC0 1.0 Universal (CC0 1.0)
License URL: https://creativecommons.org/publicdomain/zero/1.0/
Source: https://pxhere.com/en/photo/1543517

Image 3 fors slider in screenshot,  https://pxhere.com/
License: CC0 1.0 Universal (CC0 1.0)
License URL: https://creativecommons.org/publicdomain/zero/1.0/
Source: https://pxhere.com/en/photo/96946

Image 1 for Featured Categories Section,  https://pxhere.com/
License: CC0 1.0 Universal (CC0 1.0)
License URL: https://creativecommons.org/publicdomain/zero/1.0/
Source: https://pxhere.com/en/photo/1552191

Image 2 for Featured Categories Section,  https://pxhere.com/
License: CC0 1.0 Universal (CC0 1.0)
License URL: https://creativecommons.org/publicdomain/zero/1.0/
Source: https://pxhere.com/en/photo/1694346

Image 3 for Featured Categories Section,  https://pxhere.com/
License: CC0 1.0 Universal (CC0 1.0)
License URL: https://creativecommons.org/publicdomain/zero/1.0/
Source: https://pxhere.com/en/photo/703156

Image 4 for Featured Categories Section,  https://pxhere.com/
License: CC0 1.0 Universal (CC0 1.0)
License URL: https://creativecommons.org/publicdomain/zero/1.0/
Source: https://pxhere.com/en/photo/1288349

Image 1 for dummy product Section,  https://pxhere.com/
License: CC0 1.0 Universal (CC0 1.0)
License URL: https://creativecommons.org/publicdomain/zero/1.0/
Source: https://pxhere.com/en/photo/1049914

Image 2 for dummy product Section,  https://pxhere.com/
License: CC0 1.0 Universal (CC0 1.0)
License URL: https://creativecommons.org/publicdomain/zero/1.0/
Source: https://pxhere.com/en/photo/1629069

Image 3 for dummy product Section,  https://pxhere.com/
License: CC0 1.0 Universal (CC0 1.0)
License URL: https://creativecommons.org/publicdomain/zero/1.0/
Source: https://pxhere.com/en/photo/1383185

Image 4 for dummy product Section,  https://pxhere.com/
License: CC0 1.0 Universal (CC0 1.0)
License URL: https://creativecommons.org/publicdomain/zero/1.0/
Source: https://pxhere.com/en/photo/1694346

Image 5 for dummy product Section,  https://pxhere.com/
License: CC0 1.0 Universal (CC0 1.0)
License URL: https://creativecommons.org/publicdomain/zero/1.0/
Source: https://pxhere.com/en/photo/1695794

Image 6 for dummy product Section,  https://pxhere.com/
License: CC0 1.0 Universal (CC0 1.0)
License URL: https://creativecommons.org/publicdomain/zero/1.0/
Source: https://pxhere.com/en/photo/11489

Image 7 for dummy product Section,  https://pxhere.com/
License: CC0 1.0 Universal (CC0 1.0)
License URL: https://creativecommons.org/publicdomain/zero/1.0/
Source: https://pxhere.com/en/photo/1693922

Image 8 for dummy product Section,  https://pxhere.com/
License: CC0 1.0 Universal (CC0 1.0)
License URL: https://creativecommons.org/publicdomain/zero/1.0/
Source: https://pxhere.com/en/photo/1680110

Image  for CTA Background,  https://pxhere.com/
License: CC0 1.0 Universal (CC0 1.0)
License URL: https://creativecommons.org/publicdomain/zero/1.0/
Source: https://pxhere.com/en/photo/1647958

Image for testimonial 1, https://pxhere.com
License: CC0 1.0 Universal (CC0 1.0)
License URL: https://creativecommons.org/publicdomain/zero/1.0/
Source: https://pxhere.com/en/photo/451655

Image 2 for Testimonial section pattern,https://pxhere.com/
License: CC0 1.0 Universal (CC0 1.0)
License URL: https://creativecommons.org/publicdomain/zero/1.0/
Source: https://pxhere.com/en/photo/865531

Image for testimonial 3, https://pxhere.com
License: CC0 1.0 Universal (CC0 1.0)
License URL: https://creativecommons.org/publicdomain/zero/1.0/
Source: https://pxhere.com/en/photo/604504

Image for Team 1, https://pxhere.com
License: CC0 1.0 Universal (CC0 1.0)
License URL: https://creativecommons.org/publicdomain/zero/1.0/
Source: https://pxhere.com/en/photo/1175501

Image for Team 2, https://pxhere.com
License: CC0 1.0 Universal (CC0 1.0)
License URL: https://creativecommons.org/publicdomain/zero/1.0/
Source: https://pxhere.com/en/photo/645506

Image for Team 3, https://pxhere.com
License: CC0 1.0 Universal (CC0 1.0)
License URL: https://creativecommons.org/publicdomain/zero/1.0/
Source: https://pxhere.com/en/photo/1169779

Image for Team 4, https://stocksnap.io/
License: CC0 1.0 Universal (CC0 1.0)
License URL: https://creativecommons.org/publicdomain/zero/1.0/
Source: https://stocksnap.io/photo/fashion-woman-HEMZXDQJ3E

Image 1 for gallery section, https://pxhere.com/
License: CC0 1.0 Universal (CC0 1.0)
License URL: https://creativecommons.org/publicdomain/zero/1.0/
Source: https://pxhere.com/en/photo/1412909

Image 2 for gallery section, https://pxhere.com/
License: CC0 1.0 Universal (CC0 1.0)
License URL: https://creativecommons.org/publicdomain/zero/1.0/
Source: https://pxhere.com/en/photo/597756

Image 4 for gallery section, https://pxhere.com/
License: CC0 1.0 Universal (CC0 1.0)
License URL: https://creativecommons.org/publicdomain/zero/1.0/
Source: https://pxhere.com/en/photo/1647015

Image 5 for gallery section, https://pxhere.com/
License: CC0 1.0 Universal (CC0 1.0)
License URL: https://creativecommons.org/publicdomain/zero/1.0/
Source: https://pxhere.com/en/photo/1518751


Fonts credit and license:

Font: DM Sans,
Copyright 2014 The DM Sans Project Authors
License: http://scripts.sil.org/OFL
Source: https://github.com/googlefonts/dm-fonts

Font: DM Serif Display,
Copyright 2014-2018 Adobe
License: http://scripts.sil.org/OFL
Source:http://www.adobe.com/

font: Inter,
Copyright 2020 The Inter Project Authors
License: http://scripts.sil.org/OFL
Source: https://github.com/rsms/inter

Font: Manrope,
Copyright 2018 The Manrope Project Authors
License: http://scripts.sil.org/OFL
Source: https://github.com/sharanda/manrope

Font: Outfit,
Copyright 2021 The Outfit Project Authors
License: http://scripts.sil.org/OFL
Source: https://github.com/Outfitio/Outfit-Fonts

Font: Plus Jakarta Sans,
Copyright 2020 The Plus Jakarta Sans Project Authors
License: http://scripts.sil.org/OFL
Source: https://github.com/tokotype/PlusJakartaSans

Font: Public Sans
Copyright 2015 The Public Sans Project Authors
License: http://scripts.sil.org/OFL
Source: https://github.com/uswds/public-sans

Font: Quicksand,
Copyright 2011 The Quicksand Project Authors
License: http://scripts.sil.org/OFL
Source: https://github.com/andrew-paglinawan/QuicksandFamily

Font: Oswald,
Copyright 2016 The Oswald Project Authors
License: http://scripts.sil.org/OFL
Source: https://github.com/googlefonts/OswaldFont

Font: Tenor Sans,
Copyright (c) 2011, Denis Masharov <denis.masharov@gmail.com>
License: http://scripts.sil.org/OFL
Source: https://github.com/google/fonts/tree/main/ofl/tenorsans

Animation Scripts Credit and License
AOS - Animation on Scroll
Copyright (c) 2015 Michał Sajnóg,
License: MIT License
License URL: https://github.com/michalsnik/aos?tab=MIT-1-ov-file#readme
Source: https://github.com/michalsnik/aos