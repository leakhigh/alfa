<?php

/**
 * file for holding dashboard welcome page for theme
 */
if (!function_exists('woxstore_is_plugin_installed')) {
    function woxstore_is_plugin_installed($plugin_slug)
    {
        $plugin_path = WP_PLUGIN_DIR . '/' . $plugin_slug;
        return file_exists($plugin_path);
    }
}
if (!function_exists('woxstore_is_plugin_activated')) {
    function woxstore_is_plugin_activated($plugin_slug)
    {
        return is_plugin_active($plugin_slug);
    }
}
if (!function_exists('woxstore_welcome_notice')) :
    function woxstore_welcome_notice()
    {
        if (get_option('woxstore_dismissed_custom_notice')) {
            return;
        }
        global $pagenow;
        $current_screen  = get_current_screen();

        if (is_admin()) {
            if ($current_screen->id !== 'dashboard' && $current_screen->id !== 'themes') {
                return;
            }
            if (is_network_admin()) {
                return;
            }
            if (!current_user_can('manage_options')) {
                return;
            }
            $theme = wp_get_theme();

            if (is_child_theme()) {
                $theme = wp_get_theme()->parent();
            }
            $woxstore_version = $theme->get('Version');


?>
            <div class="woxstore-admin-notice notice notice-info is-dismissible content-install-plugin theme-info-notice" id="woxstore-dismiss-notice">
                <div class="info-content">
                    <div class="notice-holder">
                        <h5><span class="theme-name"><span><?php echo __('Welcome to WoxStore', 'woxstore'); ?></span></h5>
                        <h2><?php echo __('Launch Your Online Store Effortlessly with WoxStore! 🚀 ', 'woxstore'); ?></h2>
                        </h3>
                        <div class="notice-text">
                            <p><?php echo __('Please install and activate all recommended plugins to access 50+ advanced blocks, pre-built starter demos, and the one-click demo importer. Launch your online store in minutes with just a few clicks! - Cozy Blocks, Cozy Essential Addons, Advanced Import, QuiqOwl-Ajax Search for WooCommerce!', 'woxstore') ?></p>
                        </div>
                        <a href="#" id="install-activate-button" class="button admin-button info-button"><?php echo __('Getting started with a single click', 'woxstore'); ?></a>
                        <a href="<?php echo admin_url(); ?>themes.php?page=about-woxstore" class="button admin-button info-button"><?php echo __('Explore WoxStore', 'woxstore'); ?></a>

                    </div>
                </div>
                <div class="theme-hero-screens">
                    <img src="<?php echo esc_url(get_template_directory_uri() . '/inc/admin/images/theme_screen_img.png'); ?>" />
                </div>

            </div>
    <?php
        }
    }
endif;
add_action('admin_notices', 'woxstore_welcome_notice');
function woxstore_dismissble_notice()
{
    if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'woxstore_admin_nonce')) {
        wp_send_json_error(array('message' => 'Nonce verification failed.'));
        return;
    }

    $result = update_option('woxstore_dismissed_custom_notice', 1);

    if ($result) {
        wp_send_json_success();
    } else {
        wp_send_json_error(array('message' => 'Failed to update option'));
    }
}
add_action('wp_ajax_woxstore_dismissble_notice', 'woxstore_dismissble_notice');
// Hook into a custom action when the button is clicked
add_action('wp_ajax_woxstore_install_and_activate_plugins', 'woxstore_install_and_activate_plugins');
add_action('wp_ajax_nopriv_woxstore_install_and_activate_plugins', 'woxstore_install_and_activate_plugins');
add_action('wp_ajax_woxstore_rplugin_activation', 'woxstore_rplugin_activation');
add_action('wp_ajax_nopriv_woxstore_rplugin_activation', 'woxstore_rplugin_activation');

// Function to install and activate the plugins



function woxstore_check_plugin_installed_status($pugin_slug, $plugin_file)
{
    return file_exists(ABSPATH . 'wp-content/plugins/' . $pugin_slug . '/' . $plugin_file) ? true : false;
}

/* Check if plugin is activated */


function woxstore_check_plugin_active_status($pugin_slug, $plugin_file)
{
    return is_plugin_active($pugin_slug . '/' . $plugin_file) ? true : false;
}

require_once(ABSPATH . 'wp-admin/includes/plugin-install.php');
require_once(ABSPATH . 'wp-admin/includes/file.php');
require_once(ABSPATH . 'wp-admin/includes/misc.php');
require_once(ABSPATH . 'wp-admin/includes/class-wp-upgrader.php');
function woxstore_install_and_activate_plugins()
{
    if (!current_user_can('manage_options')) {
        return;
    }
    check_ajax_referer('woxstore_welcome_nonce', 'nonce');
    // Define the plugins to be installed and activated
    $recommended_plugins = array(
        array(
            'slug' => 'cozy-addons',
            'file' => 'cozy-addons.php',
            'name' => __('Cozy Blocks', 'woxstore'),
        ),
        array(
            'slug' => 'advanced-import',
            'file' => 'advanced-import.php',
            'name' => __('Advanced Imporrt', 'woxstore'),
        ),
        array(
            'slug' => 'cozy-essential-addons',
            'file' => 'cozy-essential-addons.php',
            'name' => __('Cozy Essential Addons', 'woxstore'),
        ),
        array(
            'slug' => 'quiqowl',
            'file' => 'quiqowl.php',
            'name' => __('QuiqOwl Ajax Search for WooCommerce', 'woxstore'),
        ),
        // Add more plugins here as needed
    );

    // Include the necessary WordPress functions


    // Set up a transient to store the installation progress
    set_transient('install_and_activate_progress', array(), MINUTE_IN_SECONDS * 10);

    // Loop through each plugin
    foreach ($recommended_plugins as $plugin) {
        $plugin_slug = $plugin['slug'];
        $plugin_file = $plugin['file'];
        $plugin_name = $plugin['name'];

        // Check if the plugin is active
        if (is_plugin_active($plugin_slug . '/' . $plugin_file)) {
            woxstore_update_install_and_activate_progress($plugin_name, 'Already Active');
            continue; // Skip to the next plugin
        }

        // Check if the plugin is installed but not active
        if (is_woxstore_plugin_installed($plugin_slug . '/' . $plugin_file)) {
            $activate = activate_plugin($plugin_slug . '/' . $plugin_file);
            if (is_wp_error($activate)) {
                woxstore_update_install_and_activate_progress($plugin_name, 'Error');
                continue; // Skip to the next plugin
            }
            woxstore_update_install_and_activate_progress($plugin_name, 'Activated');
            continue; // Skip to the next plugin
        }

        // Plugin is not installed or activated, proceed with installation
        woxstore_update_install_and_activate_progress($plugin_name, 'Installing');

        // Fetch plugin information
        $api = plugins_api('plugin_information', array(
            'slug' => $plugin_slug,
            'fields' => array('sections' => false),
        ));

        // Check if plugin information is fetched successfully
        if (is_wp_error($api)) {
            woxstore_update_install_and_activate_progress($plugin_name, 'Error');
            continue; // Skip to the next plugin
        }

        // Set up the plugin upgrader
        $upgrader = new Plugin_Upgrader();
        $install = $upgrader->install($api->download_link);

        // Check if installation is successful
        if ($install) {
            // Activate the plugin
            $activate = activate_plugin($plugin_slug . '/' . $plugin_file);

            // Check if activation is successful
            if (is_wp_error($activate)) {
                woxstore_update_install_and_activate_progress($plugin_name, 'Error');
                continue; // Skip to the next plugin
            }
            woxstore_update_install_and_activate_progress($plugin_name, 'Activated');
        } else {
            woxstore_update_install_and_activate_progress($plugin_name, 'Error');
        }
    }

    // Delete the progress transient
    $redirect_url = admin_url('themes.php?page=advanced-import');

    // Delete the progress transient
    delete_transient('install_and_activate_progress');
    // Return JSON response
    wp_send_json_success(array('redirect_url' => $redirect_url));
}

// Function to check if a plugin is installed but not active
function is_woxstore_plugin_installed($plugin_slug)
{
    $plugins = get_plugins();
    return isset($plugins[$plugin_slug]);
}

// Function to update the installation and activation progress
function woxstore_update_install_and_activate_progress($plugin_name, $status)
{
    $progress = get_transient('install_and_activate_progress');
    $progress[] = array(
        'plugin' => $plugin_name,
        'status' => $status,
    );
    set_transient('install_and_activate_progress', $progress, MINUTE_IN_SECONDS * 10);
}


function woxstore_dashboard_menu()
{
    add_theme_page(esc_html__('About WoxStore', 'woxstore'), esc_html__('About WoxStore', 'woxstore'), 'edit_theme_options', 'about-woxstore', 'woxstore_theme_info_display');
}
add_action('admin_menu', 'woxstore_dashboard_menu');
function woxstore_theme_info_display()
{ ?>
    <div class="dashboard-about-woxstore">
        <div class="woxstore-dashboard">
            <ul id="woxstore-dashboard-tabs-nav">
                <li><a href="#woxstore-welcome"><?php echo __('Get Started', 'woxstore') ?></a></li>
                <li><a href="#woxstore-setup"><?php echo __('Setup Instruction', 'woxstore') ?></a></li>
                <li><a href="#woxstore-comparision"><?php echo __('FREE VS PRO', 'woxstore') ?></a></li>
            </ul> <!-- END tabs-nav -->
            <div id="tabs-content">
                <div id="woxstore-welcome" class="tab-content">
                    <h1> <?php echo __('Welcome to the WoxStore', 'woxstore') ?></h1>
                    <p><?php echo __(' WoxStore is a minimal, clean, and versatile WooCommerce theme designed to help you launch and customize your online store effortlessly. Built with Full Site Editing (FSE), it gives you complete control over every element of your site, including the header, footer, product catalog, and blog layout. Ideal for any eCommerce niche — from fashion, beauty, and electronics to home decor, furniture, hardware, groceries, sports gear, jewelry, pet supplies, books, automotive parts, and kids products — WoxStore adapts to your brand’s unique style. With 9 professionally designed starter templates and a one-click demo import feature, setting up your store is quick and easy. Pre-built sections and templates make customization simple and intuitive, helping you create a high-converting store with minimal effort. Discover all features and live demos at https://cozythemes.com/woxstore-woocommerce-theme/.', 'woxstore') ?></p>
                    <h3><?php echo __('Required Plugins', 'woxstore'); ?></h3>
                    <p class="notice-text"><?php echo __('Please install and activate all recommended pluign to import the demo with "one click demo import" feature and unlock premium features!(for pro version)', 'woxstore') ?></p>
                    <ul class="woxstore-required-plugin">
                        <li>

                            <h4><?php echo __('1. Cozy Addons', 'woxstore'); ?>
                                <?php
                                if (woxstore_is_plugin_activated('cozy-addons/cozy-addons.php')) {
                                    echo __(': Plugin has been already activated!', 'woxstore');
                                } elseif (woxstore_is_plugin_installed('cozy-addons/cozy-addons.php')) {
                                    echo __(': Plugin does not activated, Activate the plugin to use one click demo import and unlock premium features.', 'woxstore');
                                } else {
                                    echo ': <a href="' . get_admin_url() . 'plugin-install.php?tab=plugin-information&plugin=cozy-addons&TB_iframe=true&width=600&height=550">' . esc_html__('Install and Activate', 'woxstore') . '</a>';
                                }
                                ?>
                            </h4>
                        </li>
                        <li>

                            <h4><?php echo __('2. Cozy Essential Addons', 'woxstore'); ?>
                                <?php
                                if (woxstore_is_plugin_activated('cozy-essential-addons/cozy-essential-addons.php')) {
                                    echo __(': Plugin has been already activated!', 'woxstore');
                                } elseif (woxstore_is_plugin_installed('cozy-essential-addons/cozy-essential-addons.php')) {
                                    echo __(': Plugin does not activated, Activate the plugin to use one click demo import and unlock premium features.', 'woxstore');
                                } else {
                                    echo ': <a href="' . get_admin_url() . 'plugin-install.php?tab=plugin-information&plugin=cozy-essential-addons&TB_iframe=true&width=600&height=550">' . esc_html__('Install and Activate', 'woxstore') . '</a>';
                                }
                                ?>
                            </h4>
                        </li>
                        <li>
                            <h4><?php echo __('3. Advanced Import - Need only to use "one click demo import" features', 'woxstore'); ?>
                                <?php
                                if (woxstore_is_plugin_activated('advanced-import/advanced-import.php')) {
                                    echo __(': Plugin has been already activated!', 'woxstore');
                                } elseif (woxstore_is_plugin_installed('advanced-import/advanced-import.php')) {
                                    echo __(': Plugin does not activated, Activate the plugin to use one click demo import feature.', 'woxstore');
                                } else {
                                    echo ': <a href="' . get_admin_url() . 'plugin-install.php?tab=plugin-information&plugin=advanced-import&TB_iframe=true&width=600&height=550">' . esc_html__('Install and Activate', 'woxstore') . '</a>';
                                }
                                ?>
                            </h4>
                        </li>
                        <li>
                            <h4><?php echo __('4. QuiqOwl - Ajax Search for WooCommerce', 'woxstore'); ?>
                                <?php
                                if (woxstore_is_plugin_activated('quiqowl/quiqowl.php')) {
                                    echo __(': Plugin has been already activated!', 'woxstore');
                                } elseif (woxstore_is_plugin_installed('quiqowl/quiqowl.php')) {
                                    echo __(': Plugin does not activated, Activate the plugin to use one click demo import feature.', 'woxstore');
                                } else {
                                    echo ': <a href="' . get_admin_url() . 'plugin-install.php?tab=plugin-information&plugin=quiqowl&TB_iframe=true&width=600&height=550">' . esc_html__('Install and Activate', 'woxstore') . '</a>';
                                }
                                ?>
                            </h4>
                        </li>
                    </ul>
                    <a href="#" id="install-activate-button" class="button admin-button info-button"><?php echo __('Getting started with a single click', 'woxstore'); ?></a>
                </div>
                <div id="woxstore-setup" class="tab-content">
                    <h3 class="woxstore-baisc-guideline-header"><?php echo __('Basic Theme Setup', 'woxstore') ?></h3>
                    <div class="woxstore-baisc-guideline">
                        <div class="featured-box">
                            <ul>
                                <li><strong><?php echo __('Setup Header Layout:', 'woxstore') ?></strong>
                                    <ul>
                                        <li> - <?php echo __('Go to Appearance -> Editor -> Patterns -> Template Parts -> Header:', 'woxstore') ?></li>
                                        <li> - <?php echo __('click on Header > Click on Edit (Icon) -> Add or Remove Requirend block/content as your requirement.:', 'woxstore') ?></li>
                                        <li> - <?php echo __('Click on save to update your layout', 'woxstore') ?></li>
                                    </ul>
                                </li>
                            </ul>
                        </div>
                        <div class="featured-box">
                            <ul>
                                <li><strong><?php echo __('Setup Footer Layout:', 'woxstore') ?></strong>
                                    <ul>
                                        <li> - <?php echo __('Go to Appearance -> Editor -> Patterns -> Template Parts -> Footer:', 'woxstore') ?></li>
                                        <li> - <?php echo __('click on Footer > Click on Edit (Icon) > Add or Remove Requirend block/content as your requirement.:', 'woxstore') ?></li>
                                        <li> - <?php echo __('Click on save to update your layout', 'woxstore') ?></li>
                                    </ul>
                                </li>
                            </ul>
                        </div>
                        <div class="featured-box">
                            <ul>
                                <li><strong><?php echo __('Setup Templates like Homepage/404/Search/Page/Single and more templates Layout:', 'woxstore') ?></strong>
                                    <ul>
                                        <li> - <?php echo __('Go to Appearance -> Editor -> Templates:', 'woxstore') ?></li>
                                        <li> - <?php echo __('click on Template(You need to edit/update) > Click on Edit (Icon) > Add or Remove Requirend block/content as your requirement.:', 'woxstore') ?></li>
                                        <li> - <?php echo __('Click on save to update your layout', 'woxstore') ?></li>
                                    </ul>
                                </li>
                            </ul>
                        </div>
                        <div class="featured-box">
                            <ul>
                                <li><strong><?php echo __('Restore/Reset Default Content layout of Template(Like: Frontpage/Blog/Archive etc.)', 'woxstore') ?></strong>
                                    <ul>
                                        <li> - <?php echo __('Go to Appearance -> Editor -> Templates:', 'woxstore') ?></li>
                                        <li> - <?php echo __('Click on Manage all Templates', 'woxstore') ?></li>
                                        <li> - <?php echo __('Click on 3 Dots icon at right side of respective Template', 'woxstore') ?></li>
                                        <li> - <?php echo __('Click on Clear Customization', 'woxstore') ?></li>
                                    </ul>
                                </li>
                            </ul>
                        </div>
                        <div class="featured-box">
                            <ul>
                                <li><strong><?php echo __('Restore/Reset Default Content layout of Template Parts(Header/Footer/Sidebar)', 'woxstore') ?></strong>
                                    <ul>
                                        <li> - <?php echo __('Go to Appearance -> Editor -> Patterns:', 'woxstore') ?></li>
                                        <li> - <?php echo __('Click on Manage All Template Parts', 'woxstore') ?></li>
                                        <li> - <?php echo __('Click on 3 Dots icon at right side of respective Template parts', 'woxstore') ?></li>
                                        <li> - <?php echo __('Click on Clear Customization', 'woxstore') ?></li>
                                    </ul>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div id="woxstore-comparision" class="tab-content">
                    <div class="featured-list">
                        <div class="half-col free-features">
                            <h3><?php echo __('WoxStore Features (Free)', 'woxstore') ?></h3>
                            <ul>
                                <li>
                                    <h4><?php echo __('WoxStore offers 20+ pre-built sections to help you launch your store effortlessly.', 'woxstore') ?></h4>
                                    <ul>
                                        <li><?php echo __('Banner Slider Section', 'woxstore') ?></li>
                                        <li><?php echo __('About Us Section', 'woxstore') ?></li>
                                        <li><?php echo __('Featured Product Categories Section', 'woxstore') ?></li>
                                        <li><?php echo __('Featured Product Section', 'woxstore') ?></li>
                                        <li><?php echo __('Call To Action Section', 'woxstore') ?></li>
                                        <li><?php echo __('Product List Columns', 'woxstore') ?></li>
                                        <li><?php echo __('Highlight Feature Section', 'woxstore') ?></li>
                                        <li><?php echo __('Testimonial Section', 'woxstore') ?></li>
                                        <li><?php echo __('Testimonial Grid Section', 'woxstore') ?></li>
                                        <li><?php echo __('Photo Gallery Section', 'woxstore') ?></li>
                                        <li><?php echo __('FAQ Section ', 'woxstore') ?></li>
                                        <li><?php echo __('Latest Post Display Section ', 'woxstore') ?></li>
                                        <li><?php echo __('Post Grid Section ', 'woxstore') ?></li>
                                        <li><?php echo __('Post List Section ', 'woxstore') ?></li>
                                        <li><?php echo __('Brands Logo Showcase', 'woxstore') ?></li>
                                        <li><?php echo __('Team Showcase', 'woxstore') ?></li>
                                        <li><?php echo __('Profile Links Card', 'woxstore') ?></li>
                                    </ul>
                                </li>

                                <li> <strong>- <?php echo __('FSE Templates Ready', 'woxstore') ?></strong>
                                    <ul>
                                        <li> <?php echo __('404 Template', 'woxstore') ?></li>
                                        <li> <?php echo __('Archive Template', 'woxstore') ?></li>
                                        <li> <?php echo __('Product Catalog Template', 'woxstore') ?></li>
                                        <li> <?php echo __('Blank Template', 'woxstore') ?></li>
                                        <li> <?php echo __('Front Page Template', 'woxstore') ?></li>
                                        <li> <?php echo __('Blog Home Template', 'woxstore') ?></li>
                                        <li> <?php echo __('Index Page Template', 'woxstore') ?></li>
                                        <li> <?php echo __('Search Template', 'woxstore') ?></li>
                                        <li> <?php echo __('Sitemap Template', 'woxstore') ?></li>
                                        <li> <?php echo __('Page Template', 'woxstore') ?></li>
                                        <li> <?php echo __('Left Sidebar Page Template', 'woxstore') ?></li>
                                        <li> <?php echo __('Right sidebar page  Template', 'woxstore') ?></li>
                                        <li> <?php echo __('Single Template', 'woxstore') ?></li>
                                        <li> <?php echo __('Single Product Template', 'woxstore') ?></li>
                                        <li> <?php echo __('Cart Page Template', 'woxstore') ?></li>
                                        <li> <?php echo __('Checkout Page Template', 'woxstore') ?></li>
                                        <li> <?php echo __('Left Sidebar Single Template', 'woxstore') ?></li>
                                        <li> <?php echo __('Full Width Single Template', 'woxstore') ?></li>

                                    </ul>
                                <li>
                                <li><strong> - <?php echo __('1 Pre-built demo', 'woxstore') ?></strong></li>
                                <li><strong> - <?php echo __('Fully Customizable Header Layout', 'woxstore') ?></strong></li>
                                <li> <strong>- <?php echo __('Fully Customizable Footer Layout ', 'woxstore') ?></strong></li>
                                <li><strong> - <?php echo __('12+ Beautiful Fonts Option', 'woxstore') ?></strong></li>
                                <li> <strong>- <?php echo __('On Scroll Animation option', 'woxstore') ?></strong></li>
                                <li> <strong>- <?php echo __('One Click Demo Import Features', 'woxstore') ?></strong></li>
                                <li> <strong>- <?php echo __('Access Cozy Blocks with upto 25+ Advanced Blocks for FSE and Gutenberg Editor', 'woxstore') ?></strong></li>
                            </ul>
                        </div>
                        <div class="half-col pro-features">
                            <h3><?php echo __('Premium Features', 'woxstore') ?></h3>
                            <p><?php echo __('WoxStore seamlessly integrates with Cozy Blocks, offering 10 advanced WooCommerce blocks and 40+ total blocks to enhance your store. Build a high-performance, conversion-focused shop effortlessly with powerful features and ready-to-use patterns for a stunning, professional look.', 'woxstore') ?></p>
                            <h4><?php echo __('9 Pre-built Starter Demos including free', 'woxstore') ?></h4>
                            <h4><?php echo __('50+ Advanced Blocks', 'woxstore') ?></h4>
                            <ul>
                                <li><?php echo __('10 WooCommerce Blocks', 'woxstore') ?></li>
                                <li><?php echo __('Product Slider Blocks', 'woxstore') ?></li>
                                <li><?php echo __('Product Grid/Carousel Block', 'woxstore') ?></li>
                                <li><?php echo __('Product Categories Block', 'woxstore') ?></li>
                                <li><?php echo __('Product Quickview Block', 'woxstore') ?></li>
                                <li><?php echo __('Product Wishlist Blocks', 'woxstore') ?></li>
                                <li><?php echo __('Related Product Blocks', 'woxstore') ?></li>
                                <li><?php echo __('Featured Products Tab Block', 'woxstore') ?></li>
                                <li><?php echo __('Categories Products Tab Block', 'woxstore') ?></li>
                                <li><?php echo __('All Product Reviews Block', 'woxstore') ?></li>
                                <li><?php echo __('Featured Product Block', 'woxstore') ?></li>
                                <li><?php echo __('Timer Countdown Block', 'woxstore') ?></li>
                                <li><?php echo __('After Before Image Block', 'woxstore') ?></li>
                                <li><?php echo __('Slider Block', 'woxstore') ?></li>
                                <li><?php echo __('Counter Block', 'woxstore') ?></li>
                                <li><?php echo __('Prgress Bar Block', 'woxstore') ?></li>
                                <li><?php echo __('Advanced Gallery with Lightbox, filterable and multiple layout', 'woxstore') ?></li>
                                <li><?php echo __('Portfolio Block with Custom Post Type with lightbox, category filterable and multiple layout', 'woxstore') ?></li>
                                <li><?php echo __('Team Block with grid and carousel', 'woxstore') ?></li>
                                <li><?php echo __('Testimonial Block with grid and carousel', 'woxstore') ?></li>
                                <li><?php echo __('15 Post and Magazine Block', 'woxstore') ?></li>
                                <li><?php echo __('Social Shares Block', 'woxstore') ?></li>
                                <li><?php echo __('Social Icons Block', 'woxstore') ?></li>
                                <li><?php echo __('Breadcrumbs Block', 'woxstore') ?></li>
                                <li><?php echo __('Popup buidler Block to display offer and flash sale', 'woxstore') ?>
                                    <?php echo __('and access', 'woxstore') ?> <a href="https://cozythemes.com/cozy-addons/" target="_blank"><?php echo __('Cozy Blocks with more than 40+ advanced block.', 'woxstore') ?></a>
                                </li>

                            </ul>
                            <br />
                            <a href="https://cozythemes.com/pricing-and-plans/" class="upgrade-btn button" target="_blank"><?php echo __('Upgrade to Pro', 'woxstore') ?></a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php
}
