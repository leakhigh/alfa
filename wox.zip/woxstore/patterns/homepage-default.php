<?php

/**
 * Title: Default Homepage
 * Slug: woxstore/homepage-default
 * Categories: woxstore-homes
 */
?>
<!-- wp:pattern {"slug":"woxstore/header-default"} /-->

<!-- wp:group {"tagName":"main","style":{"spacing":{"padding":{"top":"0","bottom":"0","left":"0","right":"0"},"margin":{"top":"0","bottom":"0"}}},"backgroundColor":"background","layout":{"type":"constrained","contentSize":"100%"}} -->
<main class="wp-block-group has-background-background-color has-background" style="margin-top:0;margin-bottom:0;padding-top:0;padding-right:0;padding-bottom:0;padding-left:0">
    <!-- wp:pattern {"slug":"woxstore/banner-slider"} /-->
    <!-- wp:pattern {"slug":"woxstore/featured-categories"} /-->
    <!-- wp:pattern {"slug":"woxstore/featured-products"} /-->
    <!-- wp:pattern {"slug":"woxstore/cta-block"} /-->
    <!-- wp:pattern {"slug":"woxstore/testimonial-section"} /-->
    <!-- wp:pattern {"slug":"woxstore/logo-showcase"} /-->
    <!-- wp:pattern {"slug":"woxstore/latest-post"} /-->
    <!-- wp:pattern {"slug":"woxstore/product-list-columns"} /-->
    <!-- wp:pattern {"slug":"woxstore/features-section"} /-->
</main>
<!-- /wp:group -->
<!-- wp:pattern {"slug":"woxstore/footer-default"} /-->