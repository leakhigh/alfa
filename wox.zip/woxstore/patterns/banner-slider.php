<?php

/**
 * Title: Banner Slider
 * Slug: woxstore/banner-slider
 * Categories: woxstore
 */
$woxstore_url = trailingslashit(get_template_directory_uri());
$woxstore_images = array(
    $woxstore_url . 'assets/images/slider_1.jpg',
    $woxstore_url . 'assets/images/slider_2.jpg',
    $woxstore_url . 'assets/images/slider_3.jpg',
);
?>
<!-- wp:group {"className":"woxstore-slider","style":{"spacing":{"padding":{"top":"0","bottom":"0","left":"0","right":"0"},"margin":{"top":"0","bottom":"0"},"blockGap":"0"}},"layout":{"type":"constrained","contentSize":"100%"}} -->
<div class="wp-block-group woxstore-slider" style="margin-top:0;margin-bottom:0;padding-top:0;padding-right:0;padding-bottom:0;padding-left:0"><!-- wp:group {"className":"woxstore-slider-holder swiper-wrapper","style":{"spacing":{"margin":{"top":"0","bottom":"0"},"padding":{"right":"0","left":"0","top":"0","bottom":"0"}}},"layout":{"type":"constrained","contentSize":"100%"}} -->
    <div class="wp-block-group woxstore-slider-holder swiper-wrapper" style="margin-top:0;margin-bottom:0;padding-top:0;padding-right:0;padding-bottom:0;padding-left:0"><!-- wp:cover {"url":"<?php echo esc_url($woxstore_images[0]) ?>","id":11101,"dimRatio":0,"customOverlayColor":"#47729e","isUserOverlayColor":false,"minHeight":760,"className":"swiper-slide","style":{"spacing":{"margin":{"top":"0","bottom":"0"}}},"layout":{"type":"constrained","contentSize":"1260px"}} -->
        <div class="wp-block-cover swiper-slide" style="margin-top:0;margin-bottom:0;min-height:760px"><span aria-hidden="true" class="wp-block-cover__background has-background-dim-0 has-background-dim" style="background-color:#47729e"></span><img class="wp-block-cover__image-background wp-image-11101" alt="" src="<?php echo esc_url($woxstore_images[0]) ?>" data-object-fit="cover" />
            <div class="wp-block-cover__inner-container"><!-- wp:group {"style":{"spacing":{"blockGap":"var:preset|spacing|40","margin":{"top":"65px"}}},"layout":{"type":"constrained","contentSize":"580px","justifyContent":"left"}} -->
                <div class="wp-block-group" style="margin-top:65px"><!-- wp:paragraph {"style":{"elements":{"link":{"color":{"text":"var:preset|color|light-color"}}},"typography":{"textTransform":"uppercase","fontStyle":"normal","fontWeight":"300"}},"textColor":"light-color","fontSize":"medium"} -->
                    <p class="has-light-color-color has-text-color has-link-color has-medium-font-size" style="font-style:normal;font-weight:300;text-transform:uppercase"><?php esc_html_e('Get Up to 75% Off – Shop Now!', 'woxstore') ?></p>
                    <!-- /wp:paragraph -->

                    <!-- wp:heading {"level":1,"style":{"typography":{"fontStyle":"normal","fontWeight":"400","lineHeight":"1.4","textTransform":"uppercase"}},"fontSize":"giga"} -->
                    <h1 class="wp-block-heading has-giga-font-size" style="font-style:normal;font-weight:400;line-height:1.4;text-transform:uppercase"><?php esc_html_e('Fashion in Every Step You Take!', 'woxstore') ?></h1>
                    <!-- /wp:heading -->

                    <!-- wp:buttons {"className":"is-style-button-transofom-on-hover","style":{"spacing":{"margin":{"top":"32px"}}}} -->
                    <div class="wp-block-buttons is-style-button-transofom-on-hover" style="margin-top:32px"><!-- wp:button {"backgroundColor":"transparent","className":"is-style-button-hover-secondary-bgcolor","style":{"spacing":{"padding":{"left":"28px","right":"28px","top":"20px","bottom":"20px"}},"border":{"radius":"0px","width":"1px"},"typography":{"fontStyle":"normal","fontWeight":"400","textTransform":"uppercase"}}} -->
                        <div class="wp-block-button is-style-button-hover-secondary-bgcolor" style="font-style:normal;font-weight:400;text-transform:uppercase"><a class="wp-block-button__link has-transparent-background-color has-background wp-element-button" style="border-width:1px;border-radius:0px;padding-top:20px;padding-right:28px;padding-bottom:20px;padding-left:28px"><?php esc_html_e('Shop Collections', 'woxstore') ?></a></div>
                        <!-- /wp:button -->
                    </div>
                    <!-- /wp:buttons -->
                </div>
                <!-- /wp:group -->
            </div>
        </div>
        <!-- /wp:cover -->

        <!-- wp:cover {"url":"<?php echo esc_url($woxstore_images[1]) ?>","id":11115,"dimRatio":0,"customOverlayColor":"#58718f","isUserOverlayColor":false,"minHeight":760,"className":"swiper-slide","style":{"spacing":{"margin":{"top":"0","bottom":"0"}}},"layout":{"type":"constrained","contentSize":"1260px"}} -->
        <div class="wp-block-cover swiper-slide" style="margin-top:0;margin-bottom:0;min-height:760px"><span aria-hidden="true" class="wp-block-cover__background has-background-dim-0 has-background-dim" style="background-color:#58718f"></span><img class="wp-block-cover__image-background wp-image-11115" alt="" src="<?php echo esc_url($woxstore_images[1]) ?>" data-object-fit="cover" />
            <div class="wp-block-cover__inner-container"><!-- wp:group {"style":{"spacing":{"blockGap":"var:preset|spacing|40","margin":{"top":"64px"}}},"layout":{"type":"constrained","contentSize":"580px","justifyContent":"left"}} -->
                <div class="wp-block-group" style="margin-top:64px"><!-- wp:paragraph {"style":{"elements":{"link":{"color":{"text":"var:preset|color|light-color"}}},"typography":{"textTransform":"uppercase","fontStyle":"normal","fontWeight":"300"}},"textColor":"light-color","fontSize":"medium"} -->
                    <p class="has-light-color-color has-text-color has-link-color has-medium-font-size" style="font-style:normal;font-weight:300;text-transform:uppercase"><?php esc_html_e('Get Up to 75% Off – Shop Now!', 'woxstore') ?></p>
                    <!-- /wp:paragraph -->

                    <!-- wp:heading {"level":1,"style":{"typography":{"fontStyle":"normal","fontWeight":"400","lineHeight":"1.4","textTransform":"uppercase"}},"fontSize":"giga"} -->
                    <h1 class="wp-block-heading has-giga-font-size" style="font-style:normal;font-weight:400;line-height:1.4;text-transform:uppercase"><?php esc_html_e('Where Style Meets Comfort!', 'woxstore') ?></h1>
                    <!-- /wp:heading -->

                    <!-- wp:buttons {"className":"is-style-button-transofom-on-hover","style":{"spacing":{"margin":{"top":"32px"}}}} -->
                    <div class="wp-block-buttons is-style-button-transofom-on-hover" style="margin-top:32px"><!-- wp:button {"backgroundColor":"transparent","className":"is-style-button-hover-secondary-bgcolor","style":{"spacing":{"padding":{"left":"28px","right":"28px","top":"20px","bottom":"20px"}},"border":{"radius":"0px","width":"1px"},"typography":{"fontStyle":"normal","fontWeight":"400","textTransform":"uppercase"}}} -->
                        <div class="wp-block-button is-style-button-hover-secondary-bgcolor" style="font-style:normal;font-weight:400;text-transform:uppercase"><a class="wp-block-button__link has-transparent-background-color has-background wp-element-button" style="border-width:1px;border-radius:0px;padding-top:20px;padding-right:28px;padding-bottom:20px;padding-left:28px"><?php esc_html_e('Shop Collections', 'woxstore') ?></a></div>
                        <!-- /wp:button -->
                    </div>
                    <!-- /wp:buttons -->
                </div>
                <!-- /wp:group -->
            </div>
        </div>
        <!-- /wp:cover -->

        <!-- wp:cover {"url":"<?php echo esc_url($woxstore_images[2]) ?>","id":11242,"dimRatio":0,"customOverlayColor":"#576a80","isUserOverlayColor":false,"minHeight":760,"className":"swiper-slide","style":{"spacing":{"margin":{"top":"0","bottom":"0"}}},"layout":{"type":"constrained","contentSize":"1260px"}} -->
        <div class="wp-block-cover swiper-slide" style="margin-top:0;margin-bottom:0;min-height:760px"><span aria-hidden="true" class="wp-block-cover__background has-background-dim-0 has-background-dim" style="background-color:#576a80"></span><img class="wp-block-cover__image-background wp-image-11242" alt="" src="<?php echo esc_url($woxstore_images[2]) ?>" data-object-fit="cover" />
            <div class="wp-block-cover__inner-container"><!-- wp:group {"style":{"spacing":{"blockGap":"var:preset|spacing|40","margin":{"top":"64px"}}},"layout":{"type":"constrained","contentSize":"640px","justifyContent":"left"}} -->
                <div class="wp-block-group" style="margin-top:64px"><!-- wp:paragraph {"style":{"elements":{"link":{"color":{"text":"var:preset|color|light-color"}}},"typography":{"textTransform":"uppercase","fontStyle":"normal","fontWeight":"300"}},"textColor":"light-color","fontSize":"medium"} -->
                    <p class="has-light-color-color has-text-color has-link-color has-medium-font-size" style="font-style:normal;font-weight:300;text-transform:uppercase"><?php esc_html_e('Get Up to 75% Off – Shop Now!', 'woxstore') ?></p>
                    <!-- /wp:paragraph -->

                    <!-- wp:heading {"level":1,"style":{"typography":{"fontStyle":"normal","fontWeight":"400","lineHeight":"1.4","textTransform":"uppercase"}},"fontSize":"giga"} -->
                    <h1 class="wp-block-heading has-giga-font-size" style="font-style:normal;font-weight:400;line-height:1.4;text-transform:uppercase"><?php esc_html_e('Unleash Your Inner Fashionista!', 'woxstore') ?></h1>
                    <!-- /wp:heading -->

                    <!-- wp:buttons {"className":"is-style-button-transofom-on-hover","style":{"spacing":{"margin":{"top":"32px"}}}} -->
                    <div class="wp-block-buttons is-style-button-transofom-on-hover" style="margin-top:32px"><!-- wp:button {"backgroundColor":"transparent","className":"is-style-button-hover-secondary-bgcolor","style":{"spacing":{"padding":{"left":"28px","right":"28px","top":"20px","bottom":"20px"}},"border":{"radius":"0px","width":"1px"},"typography":{"fontStyle":"normal","fontWeight":"400","textTransform":"uppercase"}}} -->
                        <div class="wp-block-button is-style-button-hover-secondary-bgcolor" style="font-style:normal;font-weight:400;text-transform:uppercase"><a class="wp-block-button__link has-transparent-background-color has-background wp-element-button" style="border-width:1px;border-radius:0px;padding-top:20px;padding-right:28px;padding-bottom:20px;padding-left:28px"><?php esc_html_e('Shop Collections', 'woxstore') ?>></a></div>
                        <!-- /wp:button -->
                    </div>
                    <!-- /wp:buttons -->
                </div>
                <!-- /wp:group -->
            </div>
        </div>
        <!-- /wp:cover -->
    </div>
    <!-- /wp:group -->

    <!-- wp:group {"className":"woxstore-slider-controls","style":{"spacing":{"padding":{"top":"0","bottom":"0","left":"0","right":"0"},"margin":{"top":"0","bottom":"0"}}},"layout":{"type":"constrained"}} -->
    <div class="wp-block-group woxstore-slider-controls" style="margin-top:0;margin-bottom:0;padding-top:0;padding-right:0;padding-bottom:0;padding-left:0"><!-- wp:html -->
        <div class="woxstore-button-prev swiper-button-prev"></div>
        <div class="woxstore-button-next swiper-button-next"></div>
        <div class="woxstore-pagination"></div>
        <!-- /wp:html -->
    </div>
    <!-- /wp:group -->
</div>
<!-- /wp:group -->