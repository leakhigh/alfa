<?php

/**
 * Title: Featured Categories
 * Slug: woxstore/featured-categories
 * Categories: woxstore
 */
$woxstore_url = trailingslashit(get_template_directory_uri());
$woxstore_images = array(
    $woxstore_url . 'assets/images/cat_1.jpg',
    $woxstore_url . 'assets/images/cat_2.jpg',
    $woxstore_url . 'assets/images/cat_3.jpg',
    $woxstore_url . 'assets/images/cat_4.jpg',
);
?>
<!-- wp:group {"style":{"spacing":{"margin":{"top":"0","bottom":"0"},"padding":{"right":"var:preset|spacing|40","left":"var:preset|spacing|40","top":"40px","bottom":"40px"}}},"layout":{"type":"constrained","contentSize":"1180px"}} -->
<div class="wp-block-group" style="margin-top:0;margin-bottom:0;padding-top:40px;padding-right:var(--wp--preset--spacing--40);padding-bottom:40px;padding-left:var(--wp--preset--spacing--40)"><!-- wp:columns {"style":{"spacing":{"margin":{"top":"0px","bottom":"0"},"blockGap":{"top":"20px","left":"20px"}}}} -->
    <div class="wp-block-columns" style="margin-top:0px;margin-bottom:0"><!-- wp:column -->
        <div class="wp-block-column"><!-- wp:cover {"url":"<?php echo esc_url($woxstore_images[0]) ?>","id":11123,"dimRatio":0,"overlayColor":"black-color","isUserOverlayColor":true,"minHeight":520,"contentPosition":"top left","isDark":false,"className":"is-style-woxstore-cover-hover-style","style":{"border":{"radius":"0px"},"spacing":{"padding":{"top":"40px","bottom":"40px","left":"40px","right":"40px"},"blockGap":"var:preset|spacing|20"}},"layout":{"type":"constrained"}} -->
            <div class="wp-block-cover is-light has-custom-content-position is-position-top-left is-style-woxstore-cover-hover-style" style="border-radius:0px;padding-top:40px;padding-right:40px;padding-bottom:40px;padding-left:40px;min-height:520px"><span aria-hidden="true" class="wp-block-cover__background has-black-color-background-color has-background-dim-0 has-background-dim"></span><img class="wp-block-cover__image-background wp-image-11123" alt="" src="<?php echo esc_url($woxstore_images[0]) ?>" data-object-fit="cover" />
                <div class="wp-block-cover__inner-container"><!-- wp:group {"style":{"spacing":{"blockGap":"var:preset|spacing|30","margin":{"top":"0","bottom":"0"}}},"layout":{"type":"constrained"}} -->
                    <div class="wp-block-group" style="margin-top:0;margin-bottom:0"><!-- wp:heading {"level":3,"style":{"elements":{"link":{"color":{"text":"var:preset|color|heading-color"},":hover":{"color":{"text":"var:preset|color|primary"}}}}},"textColor":"heading-color","fontSize":"xx-large"} -->
                        <h3 class="wp-block-heading has-heading-color-color has-text-color has-link-color has-xx-large-font-size"><?php esc_html_e('For Women', 'woxstore') ?></h3>
                        <!-- /wp:heading -->

                        <!-- wp:paragraph {"style":{"typography":{"textTransform":"uppercase","fontStyle":"normal","fontWeight":"300"}},"fontSize":"normal"} -->
                        <p class="has-normal-font-size" style="font-style:normal;font-weight:300;text-transform:uppercase"><?php esc_html_e('Save up to 50%', 'woxstore') ?></p>
                        <!-- /wp:paragraph -->

                        <!-- wp:buttons {"className":"is-style-button-transofom-on-hover","style":{"spacing":{"margin":{"top":"20px"}}}} -->
                        <div class="wp-block-buttons is-style-button-transofom-on-hover" style="margin-top:20px"><!-- wp:button {"backgroundColor":"transparent","textColor":"heading-color","className":"is-style-button-hover-primary-bgcolor","style":{"elements":{"link":{"color":{"text":"var:preset|color|heading-color"}}},"border":{"radius":"0px","width":"1px"},"typography":{"textTransform":"uppercase","fontStyle":"normal","fontWeight":"300"},"spacing":{"padding":{"left":"20px","right":"20px","top":"10px","bottom":"10px"}}}} -->
                            <div class="wp-block-button is-style-button-hover-primary-bgcolor" style="font-style:normal;font-weight:300;text-transform:uppercase"><a class="wp-block-button__link has-heading-color-color has-transparent-background-color has-text-color has-background has-link-color wp-element-button" style="border-width:1px;border-radius:0px;padding-top:10px;padding-right:20px;padding-bottom:10px;padding-left:20px"><?php esc_html_e('Visit Store', 'woxstore') ?></a></div>
                            <!-- /wp:button -->
                        </div>
                        <!-- /wp:buttons -->
                    </div>
                    <!-- /wp:group -->
                </div>
            </div>
            <!-- /wp:cover -->
        </div>
        <!-- /wp:column -->

        <!-- wp:column {"style":{"spacing":{"blockGap":"20px","padding":{"right":"0px","left":"0px"}}}} -->
        <div class="wp-block-column" style="padding-right:0px;padding-left:0px"><!-- wp:columns {"style":{"spacing":{"margin":{"top":"0","bottom":"0"},"blockGap":{"top":"20px","left":"20px"}}}} -->
            <div class="wp-block-columns" style="margin-top:0;margin-bottom:0"><!-- wp:column -->
                <div class="wp-block-column"><!-- wp:cover {"url":"<?php echo esc_url($woxstore_images[1]) ?>","id":11140,"dimRatio":0,"overlayColor":"black-color","isUserOverlayColor":true,"minHeight":250,"contentPosition":"top left","isDark":false,"className":"is-style-woxstore-cover-hover-style","style":{"border":{"radius":"0px"},"spacing":{"padding":{"top":"24px","bottom":"24px","left":"24px","right":"24px"}}},"layout":{"type":"constrained"}} -->
                    <div class="wp-block-cover is-light has-custom-content-position is-position-top-left is-style-woxstore-cover-hover-style" style="border-radius:0px;padding-top:24px;padding-right:24px;padding-bottom:24px;padding-left:24px;min-height:250px"><span aria-hidden="true" class="wp-block-cover__background has-black-color-background-color has-background-dim-0 has-background-dim"></span><img class="wp-block-cover__image-background wp-image-11140" alt="" src="<?php echo esc_url($woxstore_images[1]) ?>" data-object-fit="cover" />
                        <div class="wp-block-cover__inner-container"><!-- wp:group {"style":{"spacing":{"blockGap":"var:preset|spacing|30","margin":{"top":"0","bottom":"0"}}},"layout":{"type":"constrained"}} -->
                            <div class="wp-block-group" style="margin-top:0;margin-bottom:0"><!-- wp:heading {"level":3,"style":{"elements":{"link":{"color":{"text":"var:preset|color|heading-color"},":hover":{"color":{"text":"var:preset|color|primary"}}}}},"textColor":"heading-color","fontSize":"x-large"} -->
                                <h3 class="wp-block-heading has-heading-color-color has-text-color has-link-color has-x-large-font-size"><?php esc_html_e('Smart Watch', 'woxstore') ?></h3>
                                <!-- /wp:heading -->

                                <!-- wp:paragraph {"style":{"typography":{"textTransform":"uppercase","fontStyle":"normal","fontWeight":"300"}},"fontSize":"normal"} -->
                                <p class="has-normal-font-size" style="font-style:normal;font-weight:300;text-transform:uppercase"><?php esc_html_e('Save up to 40%', 'woxstore') ?></p>
                                <!-- /wp:paragraph -->

                                <!-- wp:buttons {"className":"is-style-button-transofom-on-hover","style":{"spacing":{"margin":{"top":"20px"}}}} -->
                                <div class="wp-block-buttons is-style-button-transofom-on-hover" style="margin-top:20px"><!-- wp:button {"backgroundColor":"transparent","textColor":"heading-color","className":"is-style-button-hover-primary-bgcolor","style":{"elements":{"link":{"color":{"text":"var:preset|color|heading-color"}}},"border":{"radius":"0px","width":"1px"},"typography":{"textTransform":"uppercase","fontStyle":"normal","fontWeight":"300"},"spacing":{"padding":{"left":"20px","right":"20px","top":"10px","bottom":"10px"}}}} -->
                                    <div class="wp-block-button is-style-button-hover-primary-bgcolor" style="font-style:normal;font-weight:300;text-transform:uppercase"><a class="wp-block-button__link has-heading-color-color has-transparent-background-color has-text-color has-background has-link-color wp-element-button" style="border-width:1px;border-radius:0px;padding-top:10px;padding-right:20px;padding-bottom:10px;padding-left:20px"><?php esc_html_e('Visit Store', 'woxstore') ?></a></div>
                                    <!-- /wp:button -->
                                </div>
                                <!-- /wp:buttons -->
                            </div>
                            <!-- /wp:group -->
                        </div>
                    </div>
                    <!-- /wp:cover -->
                </div>
                <!-- /wp:column -->

                <!-- wp:column -->
                <div class="wp-block-column"><!-- wp:cover {"url":"<?php echo esc_url($woxstore_images[2]) ?>","id":11152,"dimRatio":0,"overlayColor":"black-color","isUserOverlayColor":true,"minHeight":250,"contentPosition":"top left","isDark":false,"className":"is-style-woxstore-cover-hover-style","style":{"border":{"radius":"0px"},"spacing":{"padding":{"top":"24px","bottom":"24px","left":"24px","right":"24px"}}},"layout":{"type":"constrained"}} -->
                    <div class="wp-block-cover is-light has-custom-content-position is-position-top-left is-style-woxstore-cover-hover-style" style="border-radius:0px;padding-top:24px;padding-right:24px;padding-bottom:24px;padding-left:24px;min-height:250px"><span aria-hidden="true" class="wp-block-cover__background has-black-color-background-color has-background-dim-0 has-background-dim"></span><img class="wp-block-cover__image-background wp-image-11152" alt="" src="<?php echo esc_url($woxstore_images[2]) ?>" data-object-fit="cover" />
                        <div class="wp-block-cover__inner-container"><!-- wp:group {"style":{"spacing":{"blockGap":"var:preset|spacing|30","margin":{"top":"0","bottom":"0"}}},"layout":{"type":"constrained"}} -->
                            <div class="wp-block-group" style="margin-top:0;margin-bottom:0"><!-- wp:heading {"level":3,"style":{"elements":{"link":{"color":{"text":"var:preset|color|heading-color"},":hover":{"color":{"text":"var:preset|color|primary"}}}}},"textColor":"heading-color","fontSize":"x-large"} -->
                                <h3 class="wp-block-heading has-heading-color-color has-text-color has-link-color has-x-large-font-size"><?php esc_html_e('Accessories', 'woxstore') ?></h3>
                                <!-- /wp:heading -->

                                <!-- wp:paragraph {"style":{"typography":{"textTransform":"uppercase","fontStyle":"normal","fontWeight":"300"}},"fontSize":"normal"} -->
                                <p class="has-normal-font-size" style="font-style:normal;font-weight:300;text-transform:uppercase"><?php esc_html_e('Save up to 60%', 'woxstore') ?></p>
                                <!-- /wp:paragraph -->

                                <!-- wp:buttons {"className":"is-style-button-transofom-on-hover","style":{"spacing":{"margin":{"top":"20px"}}}} -->
                                <div class="wp-block-buttons is-style-button-transofom-on-hover" style="margin-top:20px"><!-- wp:button {"backgroundColor":"transparent","textColor":"heading-color","className":"is-style-button-hover-primary-bgcolor","style":{"elements":{"link":{"color":{"text":"var:preset|color|heading-color"}}},"border":{"radius":"0px","width":"1px"},"typography":{"textTransform":"uppercase","fontStyle":"normal","fontWeight":"300"},"spacing":{"padding":{"left":"20px","right":"20px","top":"10px","bottom":"10px"}}}} -->
                                    <div class="wp-block-button is-style-button-hover-primary-bgcolor" style="font-style:normal;font-weight:300;text-transform:uppercase"><a class="wp-block-button__link has-heading-color-color has-transparent-background-color has-text-color has-background has-link-color wp-element-button" style="border-width:1px;border-radius:0px;padding-top:10px;padding-right:20px;padding-bottom:10px;padding-left:20px"><?php esc_html_e('Visit Store', 'woxstore') ?></a></div>
                                    <!-- /wp:button -->
                                </div>
                                <!-- /wp:buttons -->
                            </div>
                            <!-- /wp:group -->
                        </div>
                    </div>
                    <!-- /wp:cover -->
                </div>
                <!-- /wp:column -->
            </div>
            <!-- /wp:columns -->

            <!-- wp:cover {"url":"<?php echo esc_url($woxstore_images[3]) ?>","id":11151,"dimRatio":0,"overlayColor":"black-color","isUserOverlayColor":true,"minHeight":250,"contentPosition":"top left","isDark":false,"className":"is-style-woxstore-cover-hover-style","style":{"border":{"radius":"0px"},"spacing":{"padding":{"top":"24px","bottom":"24px","left":"24px","right":"24px"}}},"layout":{"type":"constrained"}} -->
            <div class="wp-block-cover is-light has-custom-content-position is-position-top-left is-style-woxstore-cover-hover-style" style="border-radius:0px;padding-top:24px;padding-right:24px;padding-bottom:24px;padding-left:24px;min-height:250px"><span aria-hidden="true" class="wp-block-cover__background has-black-color-background-color has-background-dim-0 has-background-dim"></span><img class="wp-block-cover__image-background wp-image-11151" alt="" src="<?php echo esc_url($woxstore_images[3]) ?>" data-object-fit="cover" />
                <div class="wp-block-cover__inner-container"><!-- wp:group {"style":{"spacing":{"blockGap":"var:preset|spacing|30","margin":{"top":"0","bottom":"0"}}},"layout":{"type":"constrained"}} -->
                    <div class="wp-block-group" style="margin-top:0;margin-bottom:0"><!-- wp:heading {"level":3,"style":{"elements":{"link":{"color":{"text":"var:preset|color|heading-color"},":hover":{"color":{"text":"var:preset|color|primary"}}}}},"textColor":"heading-color","fontSize":"xx-large"} -->
                        <h3 class="wp-block-heading has-heading-color-color has-text-color has-link-color has-xx-large-font-size"><?php esc_html_e('For Men', 'woxstore') ?></h3>
                        <!-- /wp:heading -->

                        <!-- wp:paragraph {"style":{"typography":{"textTransform":"uppercase","fontStyle":"normal","fontWeight":"300"}},"fontSize":"normal"} -->
                        <p class="has-normal-font-size" style="font-style:normal;font-weight:300;text-transform:uppercase"><?php esc_html_e('Save up to 30%', 'woxstore') ?></p>
                        <!-- /wp:paragraph -->

                        <!-- wp:buttons {"className":"is-style-button-transofom-on-hover","style":{"spacing":{"margin":{"top":"20px"}}}} -->
                        <div class="wp-block-buttons is-style-button-transofom-on-hover" style="margin-top:20px"><!-- wp:button {"backgroundColor":"transparent","textColor":"heading-color","className":"is-style-button-hover-primary-bgcolor","style":{"elements":{"link":{"color":{"text":"var:preset|color|heading-color"}}},"border":{"radius":"0px","width":"1px"},"typography":{"textTransform":"uppercase","fontStyle":"normal","fontWeight":"300"},"spacing":{"padding":{"left":"20px","right":"20px","top":"10px","bottom":"10px"}}}} -->
                            <div class="wp-block-button is-style-button-hover-primary-bgcolor" style="font-style:normal;font-weight:300;text-transform:uppercase"><a class="wp-block-button__link has-heading-color-color has-transparent-background-color has-text-color has-background has-link-color wp-element-button" style="border-width:1px;border-radius:0px;padding-top:10px;padding-right:20px;padding-bottom:10px;padding-left:20px"><?php esc_html_e('Visit Store', 'woxstore') ?></a></div>
                            <!-- /wp:button -->
                        </div>
                        <!-- /wp:buttons -->
                    </div>
                    <!-- /wp:group -->
                </div>
            </div>
            <!-- /wp:cover -->
        </div>
        <!-- /wp:column -->
    </div>
    <!-- /wp:columns -->
</div>
<!-- /wp:group -->