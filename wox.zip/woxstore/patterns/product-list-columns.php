<?php

/**
 * Title: Product List Columns
 * Slug: woxstore/product-list-columns
 * Categories: woxstore
 */
if (class_exists('WooCommerce')) {
?>
    <!-- wp:group {"style":{"spacing":{"padding":{"top":"var:preset|spacing|80","bottom":"var:preset|spacing|80","left":"var:preset|spacing|40","right":"var:preset|spacing|40"},"margin":{"top":"0","bottom":"0"}}},"layout":{"type":"constrained","contentSize":"1180px"}} -->
    <div class="wp-block-group" style="margin-top:0;margin-bottom:0;padding-top:var(--wp--preset--spacing--80);padding-right:var(--wp--preset--spacing--40);padding-bottom:var(--wp--preset--spacing--80);padding-left:var(--wp--preset--spacing--40)"><!-- wp:columns {"style":{"spacing":{"blockGap":{"left":"40px"}}}} -->
        <div class="wp-block-columns"><!-- wp:column {"style":{"spacing":{"blockGap":"15px"}}} -->
            <div class="wp-block-column"><!-- wp:group {"style":{"spacing":{"margin":{"top":"0","bottom":"0"},"padding":{"bottom":"10px"}},"border":{"bottom":{"color":"var:preset|color|primary","width":"1px"},"top":[],"right":[],"left":[]}},"layout":{"type":"constrained"}} -->
                <div class="wp-block-group" style="border-bottom-color:var(--wp--preset--color--primary);border-bottom-width:1px;margin-top:0;margin-bottom:0;padding-bottom:10px"><!-- wp:heading {"level":3,"fontSize":"large"} -->
                    <h3 class="wp-block-heading has-large-font-size"><?php esc_html_e('Latest', 'woxstore') ?></h3>
                    <!-- /wp:heading -->
                </div>
                <!-- /wp:group -->

                <!-- wp:query {"queryId":21,"query":{"perPage":4,"pages":0,"offset":0,"postType":"product","order":"desc","orderBy":"date","author":"","search":"","exclude":[],"sticky":"","inherit":false,"parents":[],"format":[]}} -->
                <div class="wp-block-query"><!-- wp:post-template {"style":{"spacing":{"blockGap":"0"}}} -->
                    <!-- wp:columns {"verticalAlignment":"center","style":{"border":{"bottom":{"color":"var:preset|color|border-color","width":"1px"}},"spacing":{"padding":{"top":"10px","bottom":"10px","left":"0","right":"0"},"margin":{"top":"0","bottom":"0"}}}} -->
                    <div class="wp-block-columns are-vertically-aligned-center" style="border-bottom-color:var(--wp--preset--color--border-color);border-bottom-width:1px;margin-top:0;margin-bottom:0;padding-top:10px;padding-right:0;padding-bottom:10px;padding-left:0"><!-- wp:column {"verticalAlignment":"center","width":"110px"} -->
                        <div class="wp-block-column is-vertically-aligned-center" style="flex-basis:110px"><!-- wp:woocommerce/product-image {"showSaleBadge":false,"isDescendentOfQueryLoop":true,"width":"110px","height":"100px"} /--></div>
                        <!-- /wp:column -->

                        <!-- wp:column {"verticalAlignment":"center","width":"","style":{"spacing":{"blockGap":"0"}}} -->
                        <div class="wp-block-column is-vertically-aligned-center"><!-- wp:post-title {"isLink":true,"style":{"elements":{"link":{"color":{"text":"var:preset|color|heading-color"},":hover":{"color":{"text":"var:preset|color|primary"}}}}},"fontSize":"medium","__woocommerceNamespace":"woocommerce/product-collection/product-title"} /-->

                            <!-- wp:woocommerce/product-rating {"isDescendentOfQueryLoop":true,"textColor":"primary","fontSize":"small","style":{"elements":{"link":{"color":{"text":"var:preset|color|primary"}}},"spacing":{"margin":{"bottom":"10px"}}}} /-->

                            <!-- wp:woocommerce/product-price {"isDescendentOfQueryLoop":true} /-->
                        </div>
                        <!-- /wp:column -->
                    </div>
                    <!-- /wp:columns -->
                    <!-- /wp:post-template -->

                    <!-- wp:query-no-results -->
                    <!-- wp:paragraph {"placeholder":"Add text or blocks that will display when a query returns no results."} -->
                    <p></p>
                    <!-- /wp:paragraph -->
                    <!-- /wp:query-no-results -->
                </div>
                <!-- /wp:query -->
            </div>
            <!-- /wp:column -->

            <!-- wp:column {"style":{"spacing":{"blockGap":"15px"}}} -->
            <div class="wp-block-column"><!-- wp:group {"style":{"spacing":{"margin":{"top":"0","bottom":"0"},"padding":{"bottom":"10px"}},"border":{"bottom":{"color":"var:preset|color|primary","width":"1px"},"top":[],"right":[],"left":[]}},"layout":{"type":"constrained"}} -->
                <div class="wp-block-group" style="border-bottom-color:var(--wp--preset--color--primary);border-bottom-width:1px;margin-top:0;margin-bottom:0;padding-bottom:10px"><!-- wp:heading {"level":3,"fontSize":"large"} -->
                    <h3 class="wp-block-heading has-large-font-size"><?php esc_html_e('Top Rated', 'woxstore') ?></h3>
                    <!-- /wp:heading -->
                </div>
                <!-- /wp:group -->

                <!-- wp:woocommerce/product-collection {"queryId":0,"query":{"perPage":4,"pages":1,"offset":0,"postType":"product","order":"desc","orderBy":"rating","search":"","exclude":[],"inherit":false,"taxQuery":[],"isProductCollectionBlock":true,"featured":false,"woocommerceOnSale":false,"woocommerceStockStatus":["instock","outofstock","onbackorder"],"woocommerceAttributes":[],"woocommerceHandPickedProducts":[],"filterable":false,"relatedBy":{"categories":true,"tags":true}},"tagName":"div","displayLayout":{"type":"list","columns":5,"shrinkColumns":true},"dimensions":{"widthType":"fill"},"collection":"woocommerce/product-collection/top-rated","hideControls":["inherit","order","filterable"],"queryContextIncludes":["collection"],"__privatePreviewState":{"isPreview":false,"previewMessage":"Actual products will vary depending on the page being viewed."},"className":"woxstore-stack-products"} -->
                <div class="wp-block-woocommerce-product-collection woxstore-stack-products"><!-- wp:woocommerce/product-template -->
                    <!-- wp:columns {"verticalAlignment":"center","style":{"border":{"bottom":{"color":"var:preset|color|border-color","width":"1px"}},"spacing":{"padding":{"top":"10px","bottom":"10px","left":"0","right":"0"},"margin":{"top":"0","bottom":"0"}}}} -->
                    <div class="wp-block-columns are-vertically-aligned-center" style="border-bottom-color:var(--wp--preset--color--border-color);border-bottom-width:1px;margin-top:0;margin-bottom:0;padding-top:10px;padding-right:0;padding-bottom:10px;padding-left:0"><!-- wp:column {"verticalAlignment":"center","width":"110px"} -->
                        <div class="wp-block-column is-vertically-aligned-center" style="flex-basis:110px"><!-- wp:woocommerce/product-image {"showSaleBadge":false,"isDescendentOfQueryLoop":true,"width":"110px","height":"100px"} /--></div>
                        <!-- /wp:column -->

                        <!-- wp:column {"verticalAlignment":"center","width":"","style":{"spacing":{"blockGap":"0"}}} -->
                        <div class="wp-block-column is-vertically-aligned-center"><!-- wp:post-title {"isLink":true,"style":{"elements":{"link":{"color":{"text":"var:preset|color|heading-color"},":hover":{"color":{"text":"var:preset|color|primary"}}}}},"fontSize":"medium","__woocommerceNamespace":"woocommerce/product-collection/product-title"} /-->

                            <!-- wp:woocommerce/product-rating {"isDescendentOfQueryLoop":true,"textColor":"primary","fontSize":"small","style":{"elements":{"link":{"color":{"text":"var:preset|color|primary"}}},"spacing":{"margin":{"bottom":"10px"}}}} /-->

                            <!-- wp:woocommerce/product-price {"isDescendentOfQueryLoop":true} /-->
                        </div>
                        <!-- /wp:column -->
                    </div>
                    <!-- /wp:columns -->
                    <!-- /wp:woocommerce/product-template -->
                </div>
                <!-- /wp:woocommerce/product-collection -->
            </div>
            <!-- /wp:column -->

            <!-- wp:column {"style":{"spacing":{"blockGap":"15px"}}} -->
            <div class="wp-block-column"><!-- wp:group {"style":{"spacing":{"margin":{"top":"0","bottom":"0"},"padding":{"bottom":"10px"}},"border":{"bottom":{"color":"var:preset|color|primary","width":"1px"},"top":[],"right":[],"left":[]}},"layout":{"type":"constrained"}} -->
                <div class="wp-block-group" style="border-bottom-color:var(--wp--preset--color--primary);border-bottom-width:1px;margin-top:0;margin-bottom:0;padding-bottom:10px"><!-- wp:heading {"level":3,"fontSize":"large"} -->
                    <h3 class="wp-block-heading has-large-font-size"><?php esc_html_e('On Sale', 'woxstore') ?></h3>
                    <!-- /wp:heading -->
                </div>
                <!-- /wp:group -->

                <!-- wp:woocommerce/product-collection {"queryId":1,"query":{"perPage":4,"pages":1,"offset":0,"postType":"product","order":"asc","orderBy":"title","search":"","exclude":[],"inherit":false,"taxQuery":[],"isProductCollectionBlock":true,"featured":false,"woocommerceOnSale":true,"woocommerceStockStatus":["instock","outofstock","onbackorder"],"woocommerceAttributes":[],"woocommerceHandPickedProducts":[],"filterable":false,"relatedBy":{"categories":true,"tags":true}},"tagName":"div","displayLayout":{"type":"list","columns":5,"shrinkColumns":true},"dimensions":{"widthType":"fill"},"collection":"woocommerce/product-collection/on-sale","hideControls":["inherit","on-sale","filterable"],"queryContextIncludes":["collection"],"__privatePreviewState":{"isPreview":false,"previewMessage":"Actual products will vary depending on the page being viewed."},"className":"woxstore-stack-products"} -->
                <div class="wp-block-woocommerce-product-collection woxstore-stack-products"><!-- wp:woocommerce/product-template -->
                    <!-- wp:columns {"verticalAlignment":"center","style":{"border":{"bottom":{"color":"var:preset|color|border-color","width":"1px"}},"spacing":{"padding":{"top":"10px","bottom":"10px","left":"0","right":"0"},"margin":{"top":"0","bottom":"0"}}}} -->
                    <div class="wp-block-columns are-vertically-aligned-center" style="border-bottom-color:var(--wp--preset--color--border-color);border-bottom-width:1px;margin-top:0;margin-bottom:0;padding-top:10px;padding-right:0;padding-bottom:10px;padding-left:0"><!-- wp:column {"verticalAlignment":"center","width":"110px"} -->
                        <div class="wp-block-column is-vertically-aligned-center" style="flex-basis:110px"><!-- wp:woocommerce/product-image {"saleBadgeAlign":"left","isDescendentOfQueryLoop":true,"width":"110px","height":"100px","style":{"spacing":{"margin":{"top":"0","bottom":"0","left":"0","right":"0"},"padding":{"right":"0","left":"0","top":"0","bottom":"0"}}}} /--></div>
                        <!-- /wp:column -->

                        <!-- wp:column {"verticalAlignment":"center","width":"","style":{"spacing":{"blockGap":"0"}}} -->
                        <div class="wp-block-column is-vertically-aligned-center"><!-- wp:post-title {"isLink":true,"style":{"elements":{"link":{"color":{"text":"var:preset|color|heading-color"},":hover":{"color":{"text":"var:preset|color|primary"}}}},"spacing":{"margin":{"top":"0","bottom":"0"}}},"fontSize":"medium","__woocommerceNamespace":"woocommerce/product-collection/product-title"} /-->

                            <!-- wp:woocommerce/product-rating {"isDescendentOfQueryLoop":true,"textColor":"primary","fontSize":"small","style":{"elements":{"link":{"color":{"text":"var:preset|color|primary"}}},"spacing":{"margin":{"bottom":"10px"}}}} /-->

                            <!-- wp:woocommerce/product-price {"isDescendentOfQueryLoop":true} /-->
                        </div>
                        <!-- /wp:column -->
                    </div>
                    <!-- /wp:columns -->
                    <!-- /wp:woocommerce/product-template -->
                </div>
                <!-- /wp:woocommerce/product-collection -->
            </div>
            <!-- /wp:column -->
        </div>
        <!-- /wp:columns -->
    </div>
    <!-- /wp:group -->
<?php } else {
    $woxstore_url = trailingslashit(get_template_directory_uri());
    $woxstore_images = array(
        $woxstore_url . 'assets/images/dummy-products/product_4.jpg',
        $woxstore_url . 'assets/images/dummy-products/product_5.jpg',
        $woxstore_url . 'assets/images/dummy-products/product_6.jpg',
        $woxstore_url . 'assets/images/dummy-products/product_8.jpg',
        $woxstore_url . 'assets/images/dummy-products/product_rating.png',
    );

?>
    <!-- wp:group {"style":{"spacing":{"padding":{"top":"var:preset|spacing|80","bottom":"var:preset|spacing|80","left":"var:preset|spacing|40","right":"var:preset|spacing|40"},"margin":{"top":"0","bottom":"0"}}},"layout":{"type":"constrained","contentSize":"1180px"}} -->
    <div class="wp-block-group" style="margin-top:0;margin-bottom:0;padding-top:var(--wp--preset--spacing--80);padding-right:var(--wp--preset--spacing--40);padding-bottom:var(--wp--preset--spacing--80);padding-left:var(--wp--preset--spacing--40)"><!-- wp:columns {"style":{"spacing":{"blockGap":{"left":"40px"}}}} -->
        <div class="wp-block-columns">
            <!-- wp:column {"style":{"spacing":{"blockGap":"15px"}}} -->
            <div class="wp-block-column"><!-- wp:group {"style":{"spacing":{"margin":{"top":"0","bottom":"0"},"padding":{"bottom":"10px"}},"border":{"bottom":{"color":"var:preset|color|primary","width":"1px"},"top":[],"right":[],"left":[]}},"layout":{"type":"constrained"}} -->
                <div class="wp-block-group" style="border-bottom-color:var(--wp--preset--color--primary);border-bottom-width:1px;margin-top:0;margin-bottom:0;padding-bottom:10px"><!-- wp:heading {"level":3,"fontSize":"large"} -->
                    <h3 class="wp-block-heading has-large-font-size"><?php esc_html_e('Latest', 'woxstore') ?></h3>
                    <!-- /wp:heading -->
                </div>
                <!-- /wp:group -->

                <!-- wp:columns {"verticalAlignment":"center","style":{"spacing":{"blockGap":{"left":"var:preset|spacing|40"},"padding":{"bottom":"10px","top":"10px"},"margin":{"top":"0","bottom":"0"}},"border":{"bottom":{"color":"var:preset|color|border-color","width":"1px"}}}} -->
                <div class="wp-block-columns are-vertically-aligned-center" style="border-bottom-color:var(--wp--preset--color--border-color);border-bottom-width:1px;margin-top:0;margin-bottom:0;padding-top:10px;padding-bottom:10px"><!-- wp:column {"verticalAlignment":"center","width":"110px"} -->
                    <div class="wp-block-column is-vertically-aligned-center" style="flex-basis:110px"><!-- wp:image {"id":11299,"width":"110px","height":"100px","scale":"cover","sizeSlug":"full","linkDestination":"none"} -->
                        <figure class="wp-block-image size-full is-resized"><img src="<?php echo esc_url($woxstore_images[0]) ?>" alt="" class="wp-image-11299" style="object-fit:cover;width:110px;height:100px" /></figure>
                        <!-- /wp:image -->
                    </div>
                    <!-- /wp:column -->

                    <!-- wp:column {"verticalAlignment":"center","width":"","style":{"spacing":{"blockGap":"var:preset|spacing|20"}}} -->
                    <div class="wp-block-column is-vertically-aligned-center"><!-- wp:heading {"level":4,"style":{"spacing":{"margin":{"top":"0","bottom":"0","left":"0","right":"0"}},"typography":{"lineHeight":"1.1"}},"fontSize":"medium"} -->
                        <h4 class="wp-block-heading has-medium-font-size" style="margin-top:0;margin-right:0;margin-bottom:0;margin-left:0;line-height:1.1"><?php esc_html_e('Smart Watch', 'woxstore') ?></h4>
                        <!-- /wp:heading -->

                        <!-- wp:image {"id":11332,"width":"74px","sizeSlug":"full","linkDestination":"none","style":{"spacing":{"margin":{"top":"0px","bottom":"10px"}}}} -->
                        <figure class="wp-block-image size-full is-resized" style="margin-top:0px;margin-bottom:10px"><img src="<?php echo esc_url($woxstore_images[4]) ?>" alt="" class="wp-image-11332" style="width:74px" /></figure>
                        <!-- /wp:image -->

                        <!-- wp:paragraph -->
                        <p><?php esc_html_e('$29.00', 'woxstore') ?></p>
                        <!-- /wp:paragraph -->
                    </div>
                    <!-- /wp:column -->
                </div>
                <!-- /wp:columns -->

                <!-- wp:columns {"verticalAlignment":"center","style":{"spacing":{"blockGap":{"left":"var:preset|spacing|40"},"padding":{"bottom":"10px","top":"10px"},"margin":{"top":"0","bottom":"0"}},"border":{"bottom":{"color":"var:preset|color|border-color","width":"1px"}}}} -->
                <div class="wp-block-columns are-vertically-aligned-center" style="border-bottom-color:var(--wp--preset--color--border-color);border-bottom-width:1px;margin-top:0;margin-bottom:0;padding-top:10px;padding-bottom:10px"><!-- wp:column {"verticalAlignment":"center","width":"110px"} -->
                    <div class="wp-block-column is-vertically-aligned-center" style="flex-basis:110px"><!-- wp:image {"id":11300,"width":"110px","height":"100px","scale":"cover","sizeSlug":"full","linkDestination":"none"} -->
                        <figure class="wp-block-image size-full is-resized"><img src="<?php echo esc_url($woxstore_images[1]) ?>" alt="" class="wp-image-11300" style="object-fit:cover;width:110px;height:100px" /></figure>
                        <!-- /wp:image -->
                    </div>
                    <!-- /wp:column -->

                    <!-- wp:column {"verticalAlignment":"center","width":"","style":{"spacing":{"blockGap":"var:preset|spacing|20"}}} -->
                    <div class="wp-block-column is-vertically-aligned-center"><!-- wp:heading {"level":4,"style":{"spacing":{"margin":{"top":"0","bottom":"0","left":"0","right":"0"}},"typography":{"lineHeight":"1.1"}},"fontSize":"medium"} -->
                        <h4 class="wp-block-heading has-medium-font-size" style="margin-top:0;margin-right:0;margin-bottom:0;margin-left:0;line-height:1.1"><?php esc_html_e('Combo Set', 'woxstore') ?></h4>
                        <!-- /wp:heading -->

                        <!-- wp:image {"id":11332,"width":"74px","sizeSlug":"full","linkDestination":"none","style":{"spacing":{"margin":{"top":"0px","bottom":"10px"}}}} -->
                        <figure class="wp-block-image size-full is-resized" style="margin-top:0px;margin-bottom:10px"><img src="<?php echo esc_url($woxstore_images[4]) ?>" alt="" class="wp-image-11332" style="width:74px" /></figure>
                        <!-- /wp:image -->

                        <!-- wp:paragraph -->
                        <p><?php esc_html_e('$49.00', 'woxstore') ?></p>
                        <!-- /wp:paragraph -->
                    </div>
                    <!-- /wp:column -->
                </div>
                <!-- /wp:columns -->

                <!-- wp:columns {"verticalAlignment":"center","style":{"spacing":{"blockGap":{"left":"var:preset|spacing|40"},"padding":{"bottom":"10px","top":"10px"},"margin":{"top":"0","bottom":"0"}},"border":{"bottom":{"color":"var:preset|color|border-color","width":"1px"}}}} -->
                <div class="wp-block-columns are-vertically-aligned-center" style="border-bottom-color:var(--wp--preset--color--border-color);border-bottom-width:1px;margin-top:0;margin-bottom:0;padding-top:10px;padding-bottom:10px"><!-- wp:column {"verticalAlignment":"center","width":"110px"} -->
                    <div class="wp-block-column is-vertically-aligned-center" style="flex-basis:110px"><!-- wp:image {"id":11301,"width":"110px","height":"100px","scale":"cover","sizeSlug":"full","linkDestination":"none"} -->
                        <figure class="wp-block-image size-full is-resized"><img src="<?php echo esc_url($woxstore_images[2]) ?>" alt="" class="wp-image-11301" style="object-fit:cover;width:110px;height:100px" /></figure>
                        <!-- /wp:image -->
                    </div>
                    <!-- /wp:column -->

                    <!-- wp:column {"verticalAlignment":"center","width":"","style":{"spacing":{"blockGap":"var:preset|spacing|20"}}} -->
                    <div class="wp-block-column is-vertically-aligned-center"><!-- wp:heading {"level":4,"style":{"spacing":{"margin":{"top":"0","bottom":"0","left":"0","right":"0"}},"typography":{"lineHeight":"1.1"}},"fontSize":"medium"} -->
                        <h4 class="wp-block-heading has-medium-font-size" style="margin-top:0;margin-right:0;margin-bottom:0;margin-left:0;line-height:1.1"><?php esc_html_e('Summer Top', 'woxstore') ?></h4>
                        <!-- /wp:heading -->

                        <!-- wp:image {"id":11332,"width":"74px","sizeSlug":"full","linkDestination":"none","style":{"spacing":{"margin":{"top":"0px","bottom":"10px"}}}} -->
                        <figure class="wp-block-image size-full is-resized" style="margin-top:0px;margin-bottom:10px"><img src="<?php echo esc_url($woxstore_images[4]) ?>" alt="" class="wp-image-11332" style="width:74px" /></figure>
                        <!-- /wp:image -->

                        <!-- wp:paragraph -->
                        <p><?php esc_html_e('$29.00', 'woxstore') ?></p>
                        <!-- /wp:paragraph -->
                    </div>
                    <!-- /wp:column -->
                </div>
                <!-- /wp:columns -->

                <!-- wp:columns {"verticalAlignment":"center","style":{"spacing":{"blockGap":{"left":"var:preset|spacing|40"},"padding":{"bottom":"10px","top":"10px"},"margin":{"top":"0","bottom":"0"}},"border":{"bottom":{"color":"var:preset|color|border-color","width":"1px"}}}} -->
                <div class="wp-block-columns are-vertically-aligned-center" style="border-bottom-color:var(--wp--preset--color--border-color);border-bottom-width:1px;margin-top:0;margin-bottom:0;padding-top:10px;padding-bottom:10px"><!-- wp:column {"verticalAlignment":"center","width":"110px"} -->
                    <div class="wp-block-column is-vertically-aligned-center" style="flex-basis:110px"><!-- wp:image {"id":11302,"width":"110px","height":"100px","scale":"cover","sizeSlug":"full","linkDestination":"none"} -->
                        <figure class="wp-block-image size-full is-resized"><img src="<?php echo esc_url($woxstore_images[3]) ?>" alt="" class="wp-image-11302" style="object-fit:cover;width:110px;height:100px" /></figure>
                        <!-- /wp:image -->
                    </div>
                    <!-- /wp:column -->

                    <!-- wp:column {"verticalAlignment":"center","width":"","style":{"spacing":{"blockGap":"var:preset|spacing|20"}}} -->
                    <div class="wp-block-column is-vertically-aligned-center"><!-- wp:heading {"level":4,"style":{"spacing":{"margin":{"top":"0","bottom":"0","left":"0","right":"0"}},"typography":{"lineHeight":"1.1"}},"fontSize":"medium"} -->
                        <h4 class="wp-block-heading has-medium-font-size" style="margin-top:0;margin-right:0;margin-bottom:0;margin-left:0;line-height:1.1"><?php esc_html_e('Jordan Shoes', 'woxstore') ?></h4>
                        <!-- /wp:heading -->

                        <!-- wp:image {"id":11332,"width":"74px","sizeSlug":"full","linkDestination":"none","style":{"spacing":{"margin":{"top":"0px","bottom":"10px"}}}} -->
                        <figure class="wp-block-image size-full is-resized" style="margin-top:0px;margin-bottom:10px"><img src="<?php echo esc_url($woxstore_images[4]) ?>" alt="" class="wp-image-11332" style="width:74px" /></figure>
                        <!-- /wp:image -->

                        <!-- wp:paragraph -->
                        <p><?php esc_html_e('$29.00', 'woxstore') ?></p>
                        <!-- /wp:paragraph -->
                    </div>
                    <!-- /wp:column -->
                </div>
                <!-- /wp:columns -->
            </div>
            <!-- /wp:column -->
            <!-- wp:column {"style":{"spacing":{"blockGap":"15px"}}} -->
            <div class="wp-block-column"><!-- wp:group {"style":{"spacing":{"margin":{"top":"0","bottom":"0"},"padding":{"bottom":"10px"}},"border":{"bottom":{"color":"var:preset|color|primary","width":"1px"},"top":[],"right":[],"left":[]}},"layout":{"type":"constrained"}} -->
                <div class="wp-block-group" style="border-bottom-color:var(--wp--preset--color--primary);border-bottom-width:1px;margin-top:0;margin-bottom:0;padding-bottom:10px"><!-- wp:heading {"level":3,"fontSize":"large"} -->
                    <h3 class="wp-block-heading has-large-font-size"><?php esc_html_e('Top Rated', 'woxstore') ?></h3>
                    <!-- /wp:heading -->
                </div>
                <!-- /wp:group -->
                <!-- wp:columns {"verticalAlignment":"center","style":{"spacing":{"blockGap":{"left":"var:preset|spacing|40"},"padding":{"bottom":"10px","top":"10px"},"margin":{"top":"0","bottom":"0"}},"border":{"bottom":{"color":"var:preset|color|border-color","width":"1px"}}}} -->
                <div class="wp-block-columns are-vertically-aligned-center" style="border-bottom-color:var(--wp--preset--color--border-color);border-bottom-width:1px;margin-top:0;margin-bottom:0;padding-top:10px;padding-bottom:10px"><!-- wp:column {"verticalAlignment":"center","width":"110px"} -->
                    <div class="wp-block-column is-vertically-aligned-center" style="flex-basis:110px"><!-- wp:image {"id":11300,"width":"110px","height":"100px","scale":"cover","sizeSlug":"full","linkDestination":"none"} -->
                        <figure class="wp-block-image size-full is-resized"><img src="<?php echo esc_url($woxstore_images[1]) ?>" alt="" class="wp-image-11300" style="object-fit:cover;width:110px;height:100px" /></figure>
                        <!-- /wp:image -->
                    </div>
                    <!-- /wp:column -->

                    <!-- wp:column {"verticalAlignment":"center","width":"","style":{"spacing":{"blockGap":"var:preset|spacing|20"}}} -->
                    <div class="wp-block-column is-vertically-aligned-center"><!-- wp:heading {"level":4,"style":{"spacing":{"margin":{"top":"0","bottom":"0","left":"0","right":"0"}},"typography":{"lineHeight":"1.1"}},"fontSize":"medium"} -->
                        <h4 class="wp-block-heading has-medium-font-size" style="margin-top:0;margin-right:0;margin-bottom:0;margin-left:0;line-height:1.1"><?php esc_html_e('Combo Set', 'woxstore') ?></h4>
                        <!-- /wp:heading -->

                        <!-- wp:image {"id":11332,"width":"74px","sizeSlug":"full","linkDestination":"none","style":{"spacing":{"margin":{"top":"0px","bottom":"10px"}}}} -->
                        <figure class="wp-block-image size-full is-resized" style="margin-top:0px;margin-bottom:10px"><img src="<?php echo esc_url($woxstore_images[4]) ?>" alt="" class="wp-image-11332" style="width:74px" /></figure>
                        <!-- /wp:image -->

                        <!-- wp:paragraph -->
                        <p><?php esc_html_e('$49.00', 'woxstore') ?></p>
                        <!-- /wp:paragraph -->
                    </div>
                    <!-- /wp:column -->
                </div>
                <!-- /wp:columns -->

                <!-- wp:columns {"verticalAlignment":"center","style":{"spacing":{"blockGap":{"left":"var:preset|spacing|40"},"padding":{"bottom":"10px","top":"10px"},"margin":{"top":"0","bottom":"0"}},"border":{"bottom":{"color":"var:preset|color|border-color","width":"1px"}}}} -->
                <div class="wp-block-columns are-vertically-aligned-center" style="border-bottom-color:var(--wp--preset--color--border-color);border-bottom-width:1px;margin-top:0;margin-bottom:0;padding-top:10px;padding-bottom:10px"><!-- wp:column {"verticalAlignment":"center","width":"110px"} -->
                    <div class="wp-block-column is-vertically-aligned-center" style="flex-basis:110px"><!-- wp:image {"id":11299,"width":"110px","height":"100px","scale":"cover","sizeSlug":"full","linkDestination":"none"} -->
                        <figure class="wp-block-image size-full is-resized"><img src="<?php echo esc_url($woxstore_images[0]) ?>" alt="" class="wp-image-11299" style="object-fit:cover;width:110px;height:100px" /></figure>
                        <!-- /wp:image -->
                    </div>
                    <!-- /wp:column -->

                    <!-- wp:column {"verticalAlignment":"center","width":"","style":{"spacing":{"blockGap":"var:preset|spacing|20"}}} -->
                    <div class="wp-block-column is-vertically-aligned-center"><!-- wp:heading {"level":4,"style":{"spacing":{"margin":{"top":"0","bottom":"0","left":"0","right":"0"}},"typography":{"lineHeight":"1.1"}},"fontSize":"medium"} -->
                        <h4 class="wp-block-heading has-medium-font-size" style="margin-top:0;margin-right:0;margin-bottom:0;margin-left:0;line-height:1.1"><?php esc_html_e('Smart Watch', 'woxstore') ?></h4>
                        <!-- /wp:heading -->

                        <!-- wp:image {"id":11332,"width":"74px","sizeSlug":"full","linkDestination":"none","style":{"spacing":{"margin":{"top":"0px","bottom":"10px"}}}} -->
                        <figure class="wp-block-image size-full is-resized" style="margin-top:0px;margin-bottom:10px"><img src="<?php echo esc_url($woxstore_images[4]) ?>" alt="" class="wp-image-11332" style="width:74px" /></figure>
                        <!-- /wp:image -->

                        <!-- wp:paragraph -->
                        <p><?php esc_html_e('$29.00', 'woxstore') ?></p>
                        <!-- /wp:paragraph -->
                    </div>
                    <!-- /wp:column -->
                </div>
                <!-- /wp:columns -->
                <!-- wp:columns {"verticalAlignment":"center","style":{"spacing":{"blockGap":{"left":"var:preset|spacing|40"},"padding":{"bottom":"10px","top":"10px"},"margin":{"top":"0","bottom":"0"}},"border":{"bottom":{"color":"var:preset|color|border-color","width":"1px"}}}} -->
                <div class="wp-block-columns are-vertically-aligned-center" style="border-bottom-color:var(--wp--preset--color--border-color);border-bottom-width:1px;margin-top:0;margin-bottom:0;padding-top:10px;padding-bottom:10px"><!-- wp:column {"verticalAlignment":"center","width":"110px"} -->
                    <div class="wp-block-column is-vertically-aligned-center" style="flex-basis:110px"><!-- wp:image {"id":11302,"width":"110px","height":"100px","scale":"cover","sizeSlug":"full","linkDestination":"none"} -->
                        <figure class="wp-block-image size-full is-resized"><img src="<?php echo esc_url($woxstore_images[3]) ?>" alt="" class="wp-image-11302" style="object-fit:cover;width:110px;height:100px" /></figure>
                        <!-- /wp:image -->
                    </div>
                    <!-- /wp:column -->

                    <!-- wp:column {"verticalAlignment":"center","width":"","style":{"spacing":{"blockGap":"var:preset|spacing|20"}}} -->
                    <div class="wp-block-column is-vertically-aligned-center"><!-- wp:heading {"level":4,"style":{"spacing":{"margin":{"top":"0","bottom":"0","left":"0","right":"0"}},"typography":{"lineHeight":"1.1"}},"fontSize":"medium"} -->
                        <h4 class="wp-block-heading has-medium-font-size" style="margin-top:0;margin-right:0;margin-bottom:0;margin-left:0;line-height:1.1"><?php esc_html_e('Jordan Shoes', 'woxstore') ?></h4>
                        <!-- /wp:heading -->

                        <!-- wp:image {"id":11332,"width":"74px","sizeSlug":"full","linkDestination":"none","style":{"spacing":{"margin":{"top":"0px","bottom":"10px"}}}} -->
                        <figure class="wp-block-image size-full is-resized" style="margin-top:0px;margin-bottom:10px"><img src="<?php echo esc_url($woxstore_images[4]) ?>" alt="" class="wp-image-11332" style="width:74px" /></figure>
                        <!-- /wp:image -->

                        <!-- wp:paragraph -->
                        <p><?php esc_html_e('$29.00', 'woxstore') ?></p>
                        <!-- /wp:paragraph -->
                    </div>
                    <!-- /wp:column -->
                </div>
                <!-- /wp:columns -->


                <!-- wp:columns {"verticalAlignment":"center","style":{"spacing":{"blockGap":{"left":"var:preset|spacing|40"},"padding":{"bottom":"10px","top":"10px"},"margin":{"top":"0","bottom":"0"}},"border":{"bottom":{"color":"var:preset|color|border-color","width":"1px"}}}} -->
                <div class="wp-block-columns are-vertically-aligned-center" style="border-bottom-color:var(--wp--preset--color--border-color);border-bottom-width:1px;margin-top:0;margin-bottom:0;padding-top:10px;padding-bottom:10px"><!-- wp:column {"verticalAlignment":"center","width":"110px"} -->
                    <div class="wp-block-column is-vertically-aligned-center" style="flex-basis:110px"><!-- wp:image {"id":11301,"width":"110px","height":"100px","scale":"cover","sizeSlug":"full","linkDestination":"none"} -->
                        <figure class="wp-block-image size-full is-resized"><img src="<?php echo esc_url($woxstore_images[2]) ?>" alt="" class="wp-image-11301" style="object-fit:cover;width:110px;height:100px" /></figure>
                        <!-- /wp:image -->
                    </div>
                    <!-- /wp:column -->

                    <!-- wp:column {"verticalAlignment":"center","width":"","style":{"spacing":{"blockGap":"var:preset|spacing|20"}}} -->
                    <div class="wp-block-column is-vertically-aligned-center"><!-- wp:heading {"level":4,"style":{"spacing":{"margin":{"top":"0","bottom":"0","left":"0","right":"0"}},"typography":{"lineHeight":"1.1"}},"fontSize":"medium"} -->
                        <h4 class="wp-block-heading has-medium-font-size" style="margin-top:0;margin-right:0;margin-bottom:0;margin-left:0;line-height:1.1"><?php esc_html_e('Summer Top', 'woxstore') ?></h4>
                        <!-- /wp:heading -->

                        <!-- wp:image {"id":11332,"width":"74px","sizeSlug":"full","linkDestination":"none","style":{"spacing":{"margin":{"top":"0px","bottom":"10px"}}}} -->
                        <figure class="wp-block-image size-full is-resized" style="margin-top:0px;margin-bottom:10px"><img src="<?php echo esc_url($woxstore_images[4]) ?>" alt="" class="wp-image-11332" style="width:74px" /></figure>
                        <!-- /wp:image -->

                        <!-- wp:paragraph -->
                        <p><?php esc_html_e('$29.00', 'woxstore') ?></p>
                        <!-- /wp:paragraph -->
                    </div>
                    <!-- /wp:column -->
                </div>
                <!-- /wp:columns -->


            </div>
            <!-- /wp:column -->

            <!-- wp:column {"style":{"spacing":{"blockGap":"15px"}}} -->
            <div class="wp-block-column"><!-- wp:group {"style":{"spacing":{"margin":{"top":"0","bottom":"0"},"padding":{"bottom":"10px"}},"border":{"bottom":{"color":"var:preset|color|primary","width":"1px"},"top":[],"right":[],"left":[]}},"layout":{"type":"constrained"}} -->
                <div class="wp-block-group" style="border-bottom-color:var(--wp--preset--color--primary);border-bottom-width:1px;margin-top:0;margin-bottom:0;padding-bottom:10px"><!-- wp:heading {"level":3,"fontSize":"large"} -->
                    <h3 class="wp-block-heading has-large-font-size"><?php esc_html_e('On Sale', 'woxstore') ?></h3>
                    <!-- /wp:heading -->
                </div>
                <!-- /wp:group -->
                <!-- wp:columns {"verticalAlignment":"center","style":{"spacing":{"blockGap":{"left":"var:preset|spacing|40"},"padding":{"bottom":"10px","top":"10px"},"margin":{"top":"0","bottom":"0"}},"border":{"bottom":{"color":"var:preset|color|border-color","width":"1px"}}}} -->
                <div class="wp-block-columns are-vertically-aligned-center" style="border-bottom-color:var(--wp--preset--color--border-color);border-bottom-width:1px;margin-top:0;margin-bottom:0;padding-top:10px;padding-bottom:10px"><!-- wp:column {"verticalAlignment":"center","width":"110px"} -->
                    <div class="wp-block-column is-vertically-aligned-center" style="flex-basis:110px"><!-- wp:image {"id":11302,"width":"110px","height":"100px","scale":"cover","sizeSlug":"full","linkDestination":"none"} -->
                        <figure class="wp-block-image size-full is-resized"><img src="<?php echo esc_url($woxstore_images[3]) ?>" alt="" class="wp-image-11302" style="object-fit:cover;width:110px;height:100px" /></figure>
                        <!-- /wp:image -->
                    </div>
                    <!-- /wp:column -->

                    <!-- wp:column {"verticalAlignment":"center","width":"","style":{"spacing":{"blockGap":"var:preset|spacing|20"}}} -->
                    <div class="wp-block-column is-vertically-aligned-center"><!-- wp:heading {"level":4,"style":{"spacing":{"margin":{"top":"0","bottom":"0","left":"0","right":"0"}},"typography":{"lineHeight":"1.1"}},"fontSize":"medium"} -->
                        <h4 class="wp-block-heading has-medium-font-size" style="margin-top:0;margin-right:0;margin-bottom:0;margin-left:0;line-height:1.1"><?php esc_html_e('Jordan Shoes', 'woxstore') ?></h4>
                        <!-- /wp:heading -->

                        <!-- wp:image {"id":11332,"width":"74px","sizeSlug":"full","linkDestination":"none","style":{"spacing":{"margin":{"top":"0px","bottom":"10px"}}}} -->
                        <figure class="wp-block-image size-full is-resized" style="margin-top:0px;margin-bottom:10px"><img src="<?php echo esc_url($woxstore_images[4]) ?>" alt="" class="wp-image-11332" style="width:74px" /></figure>
                        <!-- /wp:image -->

                        <!-- wp:paragraph -->
                        <p><?php esc_html_e('$29.00', 'woxstore') ?></p>
                        <!-- /wp:paragraph -->
                    </div>
                    <!-- /wp:column -->
                </div>
                <!-- /wp:columns -->
                <!-- wp:columns {"verticalAlignment":"center","style":{"spacing":{"blockGap":{"left":"var:preset|spacing|40"},"padding":{"bottom":"10px","top":"10px"},"margin":{"top":"0","bottom":"0"}},"border":{"bottom":{"color":"var:preset|color|border-color","width":"1px"}}}} -->
                <div class="wp-block-columns are-vertically-aligned-center" style="border-bottom-color:var(--wp--preset--color--border-color);border-bottom-width:1px;margin-top:0;margin-bottom:0;padding-top:10px;padding-bottom:10px"><!-- wp:column {"verticalAlignment":"center","width":"110px"} -->
                    <div class="wp-block-column is-vertically-aligned-center" style="flex-basis:110px"><!-- wp:image {"id":11300,"width":"110px","height":"100px","scale":"cover","sizeSlug":"full","linkDestination":"none"} -->
                        <figure class="wp-block-image size-full is-resized"><img src="<?php echo esc_url($woxstore_images[1]) ?>" alt="" class="wp-image-11300" style="object-fit:cover;width:110px;height:100px" /></figure>
                        <!-- /wp:image -->
                    </div>
                    <!-- /wp:column -->

                    <!-- wp:column {"verticalAlignment":"center","width":"","style":{"spacing":{"blockGap":"var:preset|spacing|20"}}} -->
                    <div class="wp-block-column is-vertically-aligned-center"><!-- wp:heading {"level":4,"style":{"spacing":{"margin":{"top":"0","bottom":"0","left":"0","right":"0"}},"typography":{"lineHeight":"1.1"}},"fontSize":"medium"} -->
                        <h4 class="wp-block-heading has-medium-font-size" style="margin-top:0;margin-right:0;margin-bottom:0;margin-left:0;line-height:1.1"><?php esc_html_e('Combo Set', 'woxstore') ?></h4>
                        <!-- /wp:heading -->

                        <!-- wp:image {"id":11332,"width":"74px","sizeSlug":"full","linkDestination":"none","style":{"spacing":{"margin":{"top":"0px","bottom":"10px"}}}} -->
                        <figure class="wp-block-image size-full is-resized" style="margin-top:0px;margin-bottom:10px"><img src="<?php echo esc_url($woxstore_images[4]) ?>" alt="" class="wp-image-11332" style="width:74px" /></figure>
                        <!-- /wp:image -->

                        <!-- wp:paragraph -->
                        <p><?php esc_html_e('$49.00', 'woxstore') ?></p>
                        <!-- /wp:paragraph -->
                    </div>
                    <!-- /wp:column -->
                </div>
                <!-- /wp:columns -->

                <!-- wp:columns {"verticalAlignment":"center","style":{"spacing":{"blockGap":{"left":"var:preset|spacing|40"},"padding":{"bottom":"10px","top":"10px"},"margin":{"top":"0","bottom":"0"}},"border":{"bottom":{"color":"var:preset|color|border-color","width":"1px"}}}} -->
                <div class="wp-block-columns are-vertically-aligned-center" style="border-bottom-color:var(--wp--preset--color--border-color);border-bottom-width:1px;margin-top:0;margin-bottom:0;padding-top:10px;padding-bottom:10px"><!-- wp:column {"verticalAlignment":"center","width":"110px"} -->
                    <div class="wp-block-column is-vertically-aligned-center" style="flex-basis:110px"><!-- wp:image {"id":11301,"width":"110px","height":"100px","scale":"cover","sizeSlug":"full","linkDestination":"none"} -->
                        <figure class="wp-block-image size-full is-resized"><img src="<?php echo esc_url($woxstore_images[2]) ?>" alt="" class="wp-image-11301" style="object-fit:cover;width:110px;height:100px" /></figure>
                        <!-- /wp:image -->
                    </div>
                    <!-- /wp:column -->

                    <!-- wp:column {"verticalAlignment":"center","width":"","style":{"spacing":{"blockGap":"var:preset|spacing|20"}}} -->
                    <div class="wp-block-column is-vertically-aligned-center"><!-- wp:heading {"level":4,"style":{"spacing":{"margin":{"top":"0","bottom":"0","left":"0","right":"0"}},"typography":{"lineHeight":"1.1"}},"fontSize":"medium"} -->
                        <h4 class="wp-block-heading has-medium-font-size" style="margin-top:0;margin-right:0;margin-bottom:0;margin-left:0;line-height:1.1"><?php esc_html_e('Summer Top', 'woxstore') ?></h4>
                        <!-- /wp:heading -->

                        <!-- wp:image {"id":11332,"width":"74px","sizeSlug":"full","linkDestination":"none","style":{"spacing":{"margin":{"top":"0px","bottom":"10px"}}}} -->
                        <figure class="wp-block-image size-full is-resized" style="margin-top:0px;margin-bottom:10px"><img src="<?php echo esc_url($woxstore_images[4]) ?>" alt="" class="wp-image-11332" style="width:74px" /></figure>
                        <!-- /wp:image -->

                        <!-- wp:paragraph -->
                        <p><?php esc_html_e('$29.00', 'woxstore') ?></p>
                        <!-- /wp:paragraph -->
                    </div>
                    <!-- /wp:column -->
                </div>
                <!-- /wp:columns -->

                <!-- wp:columns {"verticalAlignment":"center","style":{"spacing":{"blockGap":{"left":"var:preset|spacing|40"},"padding":{"bottom":"10px","top":"10px"},"margin":{"top":"0","bottom":"0"}},"border":{"bottom":{"color":"var:preset|color|border-color","width":"1px"}}}} -->
                <div class="wp-block-columns are-vertically-aligned-center" style="border-bottom-color:var(--wp--preset--color--border-color);border-bottom-width:1px;margin-top:0;margin-bottom:0;padding-top:10px;padding-bottom:10px"><!-- wp:column {"verticalAlignment":"center","width":"110px"} -->
                    <div class="wp-block-column is-vertically-aligned-center" style="flex-basis:110px"><!-- wp:image {"id":11299,"width":"110px","height":"100px","scale":"cover","sizeSlug":"full","linkDestination":"none"} -->
                        <figure class="wp-block-image size-full is-resized"><img src="<?php echo esc_url($woxstore_images[0]) ?>" alt="" class="wp-image-11299" style="object-fit:cover;width:110px;height:100px" /></figure>
                        <!-- /wp:image -->
                    </div>
                    <!-- /wp:column -->

                    <!-- wp:column {"verticalAlignment":"center","width":"","style":{"spacing":{"blockGap":"var:preset|spacing|20"}}} -->
                    <div class="wp-block-column is-vertically-aligned-center"><!-- wp:heading {"level":4,"style":{"spacing":{"margin":{"top":"0","bottom":"0","left":"0","right":"0"}},"typography":{"lineHeight":"1.1"}},"fontSize":"medium"} -->
                        <h4 class="wp-block-heading has-medium-font-size" style="margin-top:0;margin-right:0;margin-bottom:0;margin-left:0;line-height:1.1"><?php esc_html_e('Smart Watch', 'woxstore') ?></h4>
                        <!-- /wp:heading -->

                        <!-- wp:image {"id":11332,"width":"74px","sizeSlug":"full","linkDestination":"none","style":{"spacing":{"margin":{"top":"0px","bottom":"10px"}}}} -->
                        <figure class="wp-block-image size-full is-resized" style="margin-top:0px;margin-bottom:10px"><img src="<?php echo esc_url($woxstore_images[4]) ?>" alt="" class="wp-image-11332" style="width:74px" /></figure>
                        <!-- /wp:image -->

                        <!-- wp:paragraph -->
                        <p><?php esc_html_e('$29.00', 'woxstore') ?></p>
                        <!-- /wp:paragraph -->
                    </div>
                    <!-- /wp:column -->
                </div>
                <!-- /wp:columns -->
            </div>
            <!-- /wp:column -->
        </div>
        <!-- /wp:columns -->
    </div>
    <!-- /wp:group -->

<?php }
