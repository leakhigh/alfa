<?php

/**
 * Title: Logos Showcase
 * Slug: woxstore/logo-showcase
 * Categories: woxstore
 */
$woxstore_url = trailingslashit(get_template_directory_uri());
$woxstore_images = array(
    $woxstore_url . 'assets/images/logo_1.png',
    $woxstore_url . 'assets/images/logo_2.png',
    $woxstore_url . 'assets/images/logo_3.png',
    $woxstore_url . 'assets/images/logo_4.png',
    $woxstore_url . 'assets/images/logo_5.png',
    $woxstore_url . 'assets/images/logo_6.png'
);
?>
<!-- wp:group {"metadata":{"categories":["woxstore"],"patternName":"woxstore/logo-showcase","name":"Logos Showcase"},"style":{"spacing":{"padding":{"top":"0","bottom":"0","left":"var:preset|spacing|40","right":"var:preset|spacing|40"},"margin":{"top":"0","bottom":"0"}},"border":{"bottom":{"color":"var:preset|color|background-alt","width":"1px"},"top":[],"right":[],"left":[]}},"backgroundColor":"light-color","layout":{"type":"constrained","contentSize":"100%"}} -->
<div class="wp-block-group has-light-color-background-color has-background" style="border-bottom-color:var(--wp--preset--color--background-alt);border-bottom-width:1px;margin-top:0;margin-bottom:0;padding-top:0;padding-right:var(--wp--preset--spacing--40);padding-bottom:0;padding-left:var(--wp--preset--spacing--40)"><!-- wp:group {"style":{"spacing":{"margin":{"top":"40px","bottom":"0"},"padding":{"bottom":"84px"}},"border":{"bottom":{"width":"0px","style":"none"},"top":[],"right":[],"left":[]}},"layout":{"type":"constrained","contentSize":"1040px"}} -->
    <div class="wp-block-group" style="border-bottom-style:none;border-bottom-width:0px;margin-top:40px;margin-bottom:0;padding-bottom:84px"><!-- wp:gallery {"columns":6,"imageCrop":false,"linkTo":"none","className":"woxstore-brands is-style-default","style":{"spacing":{"margin":{"top":"40px"}}}} -->
        <figure class="wp-block-gallery has-nested-images columns-6 woxstore-brands is-style-default" style="margin-top:40px"><!-- wp:image {"id":10875,"sizeSlug":"large","linkDestination":"none"} -->
            <figure class="wp-block-image size-large"><img src="<?php echo esc_url($woxstore_images[0]) ?>" alt="" class="wp-image-10875" /></figure>
            <!-- /wp:image -->

            <!-- wp:image {"id":10878,"sizeSlug":"large","linkDestination":"none"} -->
            <figure class="wp-block-image size-large"><img src="<?php echo esc_url($woxstore_images[1]) ?>" alt="" class="wp-image-10878" /></figure>
            <!-- /wp:image -->

            <!-- wp:image {"id":10876,"sizeSlug":"large","linkDestination":"none"} -->
            <figure class="wp-block-image size-large"><img src="<?php echo esc_url($woxstore_images[2]) ?>" alt="" class="wp-image-10876" /></figure>
            <!-- /wp:image -->

            <!-- wp:image {"id":10874,"sizeSlug":"large","linkDestination":"none"} -->
            <figure class="wp-block-image size-large"><img src="<?php echo esc_url($woxstore_images[3]) ?>" alt="" class="wp-image-10874" /></figure>
            <!-- /wp:image -->

            <!-- wp:image {"id":10877,"sizeSlug":"large","linkDestination":"none"} -->
            <figure class="wp-block-image size-large"><img src="<?php echo esc_url($woxstore_images[4]) ?>" alt="" class="wp-image-10877" /></figure>
            <!-- /wp:image -->

            <!-- wp:image {"id":10879,"sizeSlug":"large","linkDestination":"none"} -->
            <figure class="wp-block-image size-large"><img src="<?php echo esc_url($woxstore_images[5]) ?>" alt="" class="wp-image-10879" /></figure>
            <!-- /wp:image -->
        </figure>
        <!-- /wp:gallery -->
    </div>
    <!-- /wp:group -->
</div>
<!-- /wp:group -->